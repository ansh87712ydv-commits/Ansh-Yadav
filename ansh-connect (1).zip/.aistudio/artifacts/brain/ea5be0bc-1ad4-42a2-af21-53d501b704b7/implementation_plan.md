# ANSH CONNECT - All-In-One Secure Communication Platform

ANSH CONNECT is a production-ready, high-security Android communication platform built with Jetpack Compose. It unifies one-on-one and group messaging, WebRTC-modeled voice and video calling, ephemeral status updates, permission-governed file transfers, multi-factor security verification, and administrative monitoring into a cohesive dark glassmorphism mobile interface with a strict zero-emoji policy.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Because you skipped the initial questions, we are adopting the recommended production architecture tailored for direct Android APK export, real hardware permissions, and complete platform capability.

- **Platform Architecture**: Native Android app using Jetpack Compose with Material Design 3 and downloadable APK compilation, providing genuine runtime hardware permission dialogs (Camera, Microphone, Contacts, Notifications) and full offline resilience.
- **Strict Zero-Emoji Policy**: Every message reaction, status icon, category glyph, network indicator, and call control strictly uses precision SVG/vector line icons instead of unicode emojis.
- **Complete 34-Page Navigation Hierarchy**: All 34 required views (Welcome, Authentication, OTP Verification, Human CAPTCHA, Dashboard, Private & Group Chats, Calling Interfaces, Ephemeral Status, File Vault, Privacy Controls, Security Logs, Admin Management, and System Error Pages) are completely wired with working backstack navigation and state persistence.
- **Security & Cryptographic Guardrails**: Simulated end-to-end cryptographic key agreement (X25519 / AES-GCM simulation), client-side PBKDF2/SHA-256 credential hashing, OTP countdown cooldowns, rate-limiting, and biometric/passcode device locks.

---

## 1. Overview & Core Concept

ANSH CONNECT provides individuals, teams, and security-conscious organizations with an all-in-one communication terminal that blends the best features of modern messaging systems without branding imitations or superficial mockups.

- **Primary Persona**: Security-focused users, professionals, and administrators who require authenticated, encrypted communications with strict data privacy controls and zero distractions.
- **Key Value Proposition**: Real-time messaging, functional voice/video calling orchestration, multimedia/document vault, and administrative oversight within an ultra-polished glassmorphic HUD.

---

## 2. User Experience & Visual Design

### Visual Identity & Theme
- **Aesthetic Direction**: Tactical Cyber-Glassmorphism. Frosted dark surfaces (`#0D1117`, `#161B22`), subtle semi-transparent borders (`rgba(255, 255, 255, 0.08)`), and high-contrast emerald security accents (`#10B981` / `#34D399`) indicating encryption and active connectivity.
- **Strict No-Emoji Standard**: All message reactions (thumbs-up, heart, star, checkmark, pin) and UI affordances strictly utilize custom Vector graphics (`Icons.Outlined.*` and specialized path drawings).
- **Color Palette**:
  - `Background`: `#0A0E14` (Deep obsidian)
  - `Surface Glass`: `#111827` with 80% opacity and 1dp border stroke `#1F2937`
  - `Primary Emerald`: `#10B981` (Encryption active, verify OK, call connect)
  - `Accent Cyan`: `#06B6D4` (Active messages, attachments, status rings)
  - `Alert Coral`: `#EF4444` (End call, block user, report, 500 error)
  - `Text Primary`: `#F9FAFB` | `Text Secondary`: `#9CA3AF`
- **Typography**: Clean, geometric sans-serif styling with prominent hierarchy, uppercase micro-labels for security telemetry, and monospaced cryptographic hashes.

### Complete 34-Screen Architecture
The navigation graph is structured into 6 primary operational clusters:
1. **Onboarding & Auth Cluster (Pages 1–7)**:
   - Home / Landing
   - Welcome Screen
   - Login Page (Email/Mobile + Password + Remember Me)
   - Registration Page (Full Name, Username, Phone, Email, DOB, Gender, Password Strength Meter)
   - Mobile OTP Verification (6-digit input, countdown cooldown, resend logic)
   - Email OTP Verification (Security code validation)
   - Human Verification (Interactive math/shape CAPTCHA challenge)
2. **Core Terminal & Profile Cluster (Pages 8–10)**:
   - Main Dashboard (Telemetry, unread counters, active contacts, quick launch)
   - User Profile Page (Security tier, public key fingerprint, QR identity)
   - Edit Profile Page (Avatar picker, bio, status message, privacy toggles)
3. **Communications & Media Cluster (Pages 11–14, 20)**:
   - Chatting Hub (Active threads, search, filter unread/groups)
   - Private Chat (Encrypted bubble stream, line-icon reactions, file picker, audio recording)
   - Group Chat (Member roles, topic banner, group attachments)
   - Status Hub (24-hour disappearing text/photo updates, viewer analytics)
   - File Sharing Vault (PDF, DOCX, ZIP, media preview, download progress bars)
4. **Telephony & Realtime Calling Cluster (Pages 15–17)**:
   - Voice Calling Interface (Active duration, waveform visualization, mute/speaker/hold)
   - Video Calling Interface (Picture-in-picture local preview, remote stream, camera flip)
   - Call History (Incoming, outgoing, missed call logs with duration & timestamp)
5. **Relationship, Safety & Privacy Cluster (Pages 18–19, 21–25)**:
   - Contacts Directory (Search, alphabet scroll, online badges)
   - Contact Requests (Pending invites, approve/reject)
   - Notification Center (Categorized security, message, and call alerts)
   - Privacy & Security Suite (Last seen, read receipts, biometric lock, data export)
   - Settings Hub (Theme, network data saver, notification sounds)
   - Blocked Users Manager (Unblock/block controls)
   - Help & Support (FAQ, ticket submission, security disclosure)
6. **Administration & System Diagnostics (Pages 26–34)**:
   - Admin Login (Privileged credentials gate)
   - Admin Dashboard (Active users, server health metrics, storage gauge)
   - User Management (Search, ban, verify badges, role assignment)
   - Reports & Moderation (Flagged chats, abuse handling)
   - 404 Not Found Page (Interactive recovery & search)
   - 500 Internal Server Error (Diagnostics & stack trace suppression)
   - 502 Bad Gateway (Upstream status check & reload retry)
   - Network Error Page (Offline indicator & automatic retry pulse)
   - Maintenance Page (Scheduled maintenance timer & announcement)

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Direct Android Native Architecture vs Webview Wrapper**
  - *Chosen Approach*: Build directly using Jetpack Compose with Material 3 and modern Android runtime permissions (`ActivityResultContracts.RequestMultiplePermissions`).
  - *Why*: The user specifically requested a downloadable APK and native camera/mic/contact hardware permission dialogs.
- **Decision 2: State Management & In-Memory / Room Persistence**
  - *Chosen Approach*: Jetpack `ViewModel` combined with a reactive in-memory state repository pre-seeded with realistic cryptographic identities, chat histories, active calls, and contacts, backed by Android local persistence.
  - *Why*: Provides instant, fluid responsiveness across all 34 screens without requiring manual third-party cloud credential provisioning before initial APK inspection.
- **Decision 3: Zero-Emoji Enforcement**
  - *Chosen Approach*: Replace all typical emoji reactions with a dedicated Vector Reaction Palette (Applaud, Shield, Star, Checkmark, Flag, Heart outline).
  - *Why*: Fulfills the user's explicit cybersecurity and professional UX requirement.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        ANSH CONNECT SYSTEM ARCHITECTURE                 │
└────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                     Jetpack Compose UI Layer (M3)                      │
│  ┌───────────────────────┬──────────────────────┬────────────────────┐ │
│  │ Auth & Verify (1-7)   │ Comms & Calls (11-17)│ Admin & Ops (26-34)│ │
│  │ Dashboard & Hub (8-10)│ Safety & Vault(18-25)│ Diagnostics Screens│ │
│  └───────────────────────┴──────────────────────┴────────────────────┘ │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Navigation State & Screen Enums
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                AnshConnectViewModel & Permission Manager               │
│  - Active Screen State Machine (34 Distinct Destinations + Backstack)  │
│  - Runtime Permission Launchers (CAMERA, RECORD_AUDIO, READ_CONTACTS)  │
│  - Authentication, Verification & Rate-Limiter Engine                  │
│  - Real-Time Messaging & Calling Controller                            │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   Secure Local Repository & Data Models                │
│  - User Profile & Session Store                                        │
│  - Contacts & Contact Requests Repository                              │
│  - Messages & Thread Storage (E2EE Packet Simulation)                  │
│  - Active Calls State Machine (Ringing, Connected, Terminated)         │
│  - System Audit & Security Incident Logs                               │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Models & State Contracts
- `UserProfile`: ID, username, fullName, email, phone, gender, avatar, securityTier, isVerified, twoFactorEnabled, createdAt.
- `Message`: ID, conversationId, senderId, textContent, attachment (URL, type, size, name), timestamp, status (SENT, DELIVERED, READ), isEncrypted, reactionList (List<LineReaction>).
- `CallSession`: callId, peerUser, callType (AUDIO, VIDEO), callState (CALLING, RINGING, CONNECTED, ENDED), durationSeconds, isMuted, isCameraOff, isSpeakerOn.
- `StatusUpdate`: ID, userId, userName, mediaUri, caption, timestamp, expirationTimestamp, viewersCount.
- `AuditLog`: ID, eventType, ipAddress, deviceModel, timestamp, isSuspicious.

---

## 5. Verification Plan
1. **Compilation Check**: Run `compile_applet` to verify clean build under Android 36 SDK with Jetpack Compose.
2. **Permission Verification**: Ensure `AndroidManifest.xml` declares `CAMERA`, `RECORD_AUDIO`, `READ_CONTACTS`, `INTERNET`, `VIBRATE`, and `POST_NOTIFICATIONS`.
3. **Navigation Walkthrough**: Test transitions across all 34 screens (Auth -> Dashboard -> Chat -> Call -> Settings -> Admin -> Errors).
4. **Zero-Emoji Audit**: Verify no emojis are present across text, buttons, status, or message reactions.
