package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.ScreenId
import com.example.ui.components.PermissionDialog
import com.example.ui.screens.AdminDashboardPage
import com.example.ui.screens.AdminLoginPage
import com.example.ui.screens.BlockedUsersPage
import com.example.ui.screens.CallHistoryPage
import com.example.ui.screens.ChattingHubPage
import com.example.ui.screens.ContactRequestsPage
import com.example.ui.screens.ContactsPage
import com.example.ui.screens.EditProfilePage
import com.example.ui.screens.EmailOtpPage
import com.example.ui.screens.Error404Page
import com.example.ui.screens.Error500Page
import com.example.ui.screens.Error502Page
import com.example.ui.screens.FileSharingPage
import com.example.ui.screens.GroupChatPage
import com.example.ui.screens.HelpSupportPage
import com.example.ui.screens.HomePage
import com.example.ui.screens.HumanVerificationPage
import com.example.ui.screens.LoginPage
import com.example.ui.screens.MainDashboardPage
import com.example.ui.screens.MaintenancePage
import com.example.ui.screens.MobileOtpPage
import com.example.ui.screens.NetworkErrorPage
import com.example.ui.screens.NotificationPage
import com.example.ui.screens.PrivacySecurityPage
import com.example.ui.screens.PrivateChatPage
import com.example.ui.screens.RegistrationPage
import com.example.ui.screens.ReportsModerationPage
import com.example.ui.screens.SettingsPage
import com.example.ui.screens.StatusPage
import com.example.ui.screens.UserManagementPage
import com.example.ui.screens.UserProfilePage
import com.example.ui.screens.VideoCallingPage
import com.example.ui.screens.VoiceCallingPage
import com.example.ui.screens.WelcomePage
import com.example.ui.theme.AnshConnectTheme
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.viewmodel.AnshViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AnshConnectTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = AnshObsidianBg
                ) {
                    val viewModel: AnshViewModel = viewModel()
                    AnshConnectApp(
                        viewModel = viewModel,
                        onShowToast = { msg ->
                            Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun AnshConnectApp(
    viewModel: AnshViewModel,
    onShowToast: (String) -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val showPermissionModal by viewModel.showPermissionModal.collectAsState()
    val permissionTypeRequested by viewModel.permissionTypeRequested.collectAsState()

    // Real Android hardware permission launcher
    val permissionsToRequest = buildList {
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) {
            onShowToast("Hardware Security Permissions Granted")
        } else {
            onShowToast("Partial permissions granted. Some hardware features may be limited.")
        }
    }

    // Hardware Permission Dialog Modal
    if (showPermissionModal) {
        PermissionDialog(
            permissionType = permissionTypeRequested,
            onDismiss = { viewModel.dismissPermissionModal() },
            onGrantRealHardware = {
                permissionLauncher.launch(permissionsToRequest)
            }
        )
    }

    // Predictive / Native Back Navigation Handling
    BackHandler(enabled = currentScreen != ScreenId.MAIN_DASHBOARD && currentScreen != ScreenId.WELCOME) {
        viewModel.popBackStack()
    }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            ScreenId.HOME -> HomePage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.WELCOME -> WelcomePage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.LOGIN -> LoginPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.REGISTRATION -> RegistrationPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.MOBILE_OTP -> MobileOtpPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.EMAIL_OTP -> EmailOtpPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.HUMAN_VERIFICATION -> HumanVerificationPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.MAIN_DASHBOARD -> MainDashboardPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.USER_PROFILE -> UserProfilePage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.EDIT_PROFILE -> EditProfilePage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.CHATTING -> ChattingHubPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.PRIVATE_CHAT -> PrivateChatPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.GROUP_CHAT -> GroupChatPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.STATUS -> StatusPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.VOICE_CALLING -> VoiceCallingPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.VIDEO_CALLING -> VideoCallingPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.CALL_HISTORY -> CallHistoryPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.CONTACTS -> ContactsPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.CONTACT_REQUESTS -> ContactRequestsPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.FILE_SHARING -> FileSharingPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.NOTIFICATION -> NotificationPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.PRIVACY_SECURITY -> PrivacySecurityPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.SETTINGS -> SettingsPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.BLOCKED_USERS -> BlockedUsersPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.HELP_SUPPORT -> HelpSupportPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.ADMIN_LOGIN -> AdminLoginPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.ADMIN_DASHBOARD -> AdminDashboardPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.USER_MANAGEMENT -> UserManagementPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.REPORTS_MODERATION -> ReportsModerationPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.ERROR_404 -> Error404Page(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.ERROR_500 -> Error500Page(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.ERROR_502 -> Error502Page(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.NETWORK_ERROR -> NetworkErrorPage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
            ScreenId.MAINTENANCE -> MaintenancePage(viewModel = viewModel, onNavigate = { viewModel.navigateTo(it) })
        }
    }
}
