package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkCyberColorScheme = darkColorScheme(
    primary = AnshEmeraldPrimary,
    onPrimary = Color.Black,
    primaryContainer = AnshEmeraldContainer,
    onPrimaryContainer = AnshOnEmeraldContainer,
    secondary = AnshCyanSecondary,
    onSecondary = Color.Black,
    secondaryContainer = AnshCyanContainer,
    onSecondaryContainer = AnshOnCyanContainer,
    tertiary = AnshEmeraldLight,
    onTertiary = Color.Black,
    background = AnshObsidianBg,
    onBackground = AnshTextPrimary,
    surface = AnshGlassSurface,
    onSurface = AnshTextPrimary,
    surfaceVariant = AnshGlassSurfaceVariant,
    onSurfaceVariant = AnshTextSecondary,
    outline = AnshGlassBorder,
    error = AnshAlertRed,
    onError = Color.White,
    errorContainer = AnshAlertContainer,
    onErrorContainer = Color(0xFFFCA5A5)
)

val LightCyberColorScheme = lightColorScheme(
    primary = AnshEmeraldDark,
    onPrimary = Color.White,
    primaryContainer = AnshOnEmeraldContainer,
    onPrimaryContainer = AnshEmeraldDark,
    secondary = Color(0xFF0891B2),
    onSecondary = Color.White,
    secondaryContainer = AnshOnCyanContainer,
    onSecondaryContainer = Color(0xFF164E63),
    tertiary = AnshEmeraldPrimary,
    onTertiary = Color.Black,
    background = AnshLightBg,
    onBackground = AnshLightText,
    surface = AnshLightSurface,
    onSurface = AnshLightText,
    surfaceVariant = Color(0xFFE5E7EB),
    onSurfaceVariant = Color(0xFF4B5563),
    outline = Color(0xFFD1D5DB),
    error = AnshAlertRed,
    onError = Color.White
)

@Composable
fun AnshConnectTheme(
    darkTheme: Boolean = true, // Default to premium dark glassmorphism
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkCyberColorScheme else LightCyberColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
