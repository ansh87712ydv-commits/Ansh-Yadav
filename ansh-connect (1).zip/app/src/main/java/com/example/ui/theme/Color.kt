package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tactical Obsidian & Emerald Cyber Palette for ANSH CONNECT
val AnshEmeraldPrimary = Color(0xFF10B981)
val AnshEmeraldLight = Color(0xFF34D399)
val AnshEmeraldDark = Color(0xFF047857)
val AnshEmeraldContainer = Color(0xFF064E3B)
val AnshOnEmeraldContainer = Color(0xFFA7F3D0)

val AnshCyanSecondary = Color(0xFF06B6D4)
val AnshCyanContainer = Color(0xFF164E63)
val AnshOnCyanContainer = Color(0xFFCFFAFE)

val AnshObsidianBg = Color(0xFF0A0E14)
val AnshGlassSurface = Color(0xFF111827)
val AnshGlassSurfaceVariant = Color(0xFF1F2937)
val AnshGlassBorder = Color(0xFF374151)
val AnshGlassCard = Color(0xCC161F2E)

val AnshTextPrimary = Color(0xFFF9FAFB)
val AnshTextSecondary = Color(0xFF9CA3AF)
val AnshTextMuted = Color(0xFF6B7280)

val AnshAlertRed = Color(0xFFEF4444)
val AnshAlertContainer = Color(0xFF450A0A)
val AnshWarningAmber = Color(0xFFF59E0B)

val AnshLightBg = Color(0xFFF3F4F6)
val AnshLightSurface = Color(0xFFFFFFFF)
val AnshLightText = Color(0xFF111827)
