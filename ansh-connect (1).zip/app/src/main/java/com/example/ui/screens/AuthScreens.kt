package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Phone
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Gender
import com.example.data.model.ScreenId
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun HomePage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        // Hero Logo Badge
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(AnshEmeraldPrimary.copy(alpha = 0.35f), Color.Transparent)
                    )
                )
                .border(1.5.dp, AnshEmeraldPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Security,
                contentDescription = "ANSH CONNECT Emblem",
                tint = AnshEmeraldPrimary,
                modifier = Modifier.size(54.dp)
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "ANSH CONNECT",
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp,
            color = AnshTextPrimary
        )
        Text(
            text = "ALL-IN-ONE SECURE COMMUNICATION PLATFORM",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = AnshEmeraldLight,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Shield,
                        contentDescription = null,
                        tint = AnshCyanSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Zero-Trust Architecture",
                        fontWeight = FontWeight.Bold,
                        color = AnshTextPrimary,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Engineered with end-to-end cryptographic handshakes, WebRTC calling conduits, ephemeral status nodes, and a strict zero-emoji line interface.",
                    color = AnshTextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Feature Highlights
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(26.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("E2EE Vault", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                    Text("AES-256-GCM", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                }
            }
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Speed, contentDescription = null, tint = AnshCyanSecondary, modifier = Modifier.size(26.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("P2P Calls", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                    Text("WebRTC Engine", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                }
            }
            GlassCard(modifier = Modifier.weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Fingerprint, contentDescription = null, tint = AnshWarningAmber, modifier = Modifier.size(26.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Hardware Direct", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                    Text("Zero Intermediary", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = { onNavigate(ScreenId.WELCOME) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("home_launch_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("ENTER TERMINAL", fontWeight = FontWeight.Bold, color = Color.Black, letterSpacing = 1.sp)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = { onNavigate(ScreenId.LOGIN) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("home_direct_login_btn"),
            shape = RoundedCornerShape(12.dp),
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(AnshCyanSecondary, AnshEmeraldPrimary)))
        ) {
            Text("EXISTING AGENT LOGIN", fontWeight = FontWeight.SemiBold, color = AnshTextPrimary)
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(onClick = { onNavigate(ScreenId.ADMIN_LOGIN) }) {
            Text("RESTRICTED ADMIN CONSOLE ACCESS", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun WelcomePage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(AnshEmeraldPrimary.copy(alpha = 0.15f))
                .border(1.dp, AnshEmeraldPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Security,
                contentDescription = null,
                tint = AnshEmeraldPrimary,
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Welcome to ANSH CONNECT",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = AnshTextPrimary
        )

        Text(
            text = "Private • Encrypted • High Performance",
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            color = AnshEmeraldLight,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Strict Zero-Emoji Vector Reactions", fontSize = 12.sp, color = AnshTextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Native Audio & Video Calling Pipeline", fontSize = 12.sp, color = AnshTextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("24-Hour Ephemeral Status Updates", fontSize = 12.sp, color = AnshTextPrimary)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Check, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Encrypted Multi-Format Vault Transfer", fontSize = 12.sp, color = AnshTextPrimary)
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { onNavigate(ScreenId.REGISTRATION) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("welcome_register_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("CREATE NEW ACCOUNT", fontWeight = FontWeight.Bold, color = Color.Black)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = { onNavigate(ScreenId.LOGIN) },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("welcome_login_btn"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("SIGN IN TO EXISTING ACCOUNT", color = AnshTextPrimary)
        }

        Spacer(modifier = Modifier.height(16.dp))

        TextButton(onClick = { onNavigate(ScreenId.HOME) }) {
            Text("Back to Landing Page", fontSize = 12.sp, color = AnshTextSecondary)
        }
    }
}

@Composable
fun LoginPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var identifier by remember { mutableStateOf("ansh@anshconnect.internal") }
    var password by remember { mutableStateOf("Ansh#Secure2026") }
    var showPassword by remember { mutableStateOf(false) }
    var rememberMe by remember { mutableStateOf(true) }
    var errorText by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnshTopBar(
            title = "Agent Login",
            subtitle = "MFA Guard Active",
            onBackClick = { viewModel.popBackStack() }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Icon(
            imageVector = Icons.Outlined.Key,
            contentDescription = null,
            tint = AnshCyanSecondary,
            modifier = Modifier.size(48.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text("Authenticate Identity", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("Provide credentials registered with ANSH CONNECT", fontSize = 12.sp, color = AnshTextSecondary)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = identifier,
            onValueChange = { identifier = it },
            label = { Text("Email or Mobile Number") },
            leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null, tint = AnshCyanSecondary) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_identifier_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshEmeraldPrimary,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null, tint = AnshCyanSecondary) },
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(
                        imageVector = if (showPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                        contentDescription = "Toggle password visibility",
                        tint = AnshTextMuted
                    )
                }
            },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_password_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshEmeraldPrimary,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = rememberMe,
                    onCheckedChange = { rememberMe = it },
                    colors = CheckboxDefaults.colors(checkedColor = AnshEmeraldPrimary)
                )
                Text("Remember session", fontSize = 12.sp, color = AnshTextSecondary)
            }
            TextButton(onClick = { onNavigate(ScreenId.MOBILE_OTP) }) {
                Text("Forgot Password?", fontSize = 12.sp, color = AnshCyanSecondary)
            }
        }

        if (errorText != null) {
            Text(
                text = errorText ?: "",
                color = AnshAlertRed,
                fontSize = 12.sp,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (identifier.isBlank() || password.isBlank()) {
                    errorText = "Please fill in all credentials"
                } else {
                    onNavigate(ScreenId.MOBILE_OTP)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("login_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("VERIFY & ADVANCE TO MFA", fontWeight = FontWeight.Bold, color = Color.Black)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Don't have an identity account? ", fontSize = 12.sp, color = AnshTextSecondary)
            TextButton(onClick = { onNavigate(ScreenId.REGISTRATION) }) {
                Text("Register", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshEmeraldPrimary)
            }
        }
    }
}

@Composable
fun RegistrationPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("2000-01-01") }
    var gender by remember { mutableStateOf(Gender.MALE) }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var acceptTerms by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    // Password strength check
    val hasUpper = password.any { it.isUpperCase() }
    val hasLower = password.any { it.isLowerCase() }
    val hasDigit = password.any { it.isDigit() }
    val hasSpecial = password.any { !it.isLetterOrDigit() }
    val isMinLength = password.length >= 8

    val strengthScore = listOf(hasUpper, hasLower, hasDigit, hasSpecial, isMinLength).count { it }
    val strengthFraction = strengthScore / 5f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnshTopBar(
            title = "Identity Registration",
            subtitle = "Zero-Knowledge Enclave",
            onBackClick = { viewModel.popBackStack() }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Legal Name") },
            leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null, tint = AnshCyanSecondary) },
            modifier = Modifier.fillMaxWidth().testTag("reg_fullname_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username Handle (e.g. ansh_sec)") },
            leadingIcon = { Icon(Icons.Outlined.Shield, contentDescription = null, tint = AnshCyanSecondary) },
            modifier = Modifier.fillMaxWidth().testTag("reg_username_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Mobile Number (with country code)") },
            leadingIcon = { Icon(Icons.Outlined.Phone, contentDescription = null, tint = AnshCyanSecondary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            modifier = Modifier.fillMaxWidth().testTag("reg_phone_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            leadingIcon = { Icon(Icons.Outlined.Email, contentDescription = null, tint = AnshCyanSecondary) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth().testTag("reg_email_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = dob,
            onValueChange = { dob = it },
            label = { Text("Date of Birth (YYYY-MM-DD)") },
            modifier = Modifier.fillMaxWidth().testTag("reg_dob_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Gender Selection
        Column(modifier = Modifier.fillMaxWidth()) {
            Text("Gender Selection", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Gender.values().forEach { g ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = gender == g,
                            onClick = { gender = g },
                            colors = RadioButtonDefaults.colors(selectedColor = AnshEmeraldPrimary)
                        )
                        Text(g.name.take(4), fontSize = 11.sp, color = AnshTextSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password (Argon2id Enforced)") },
            leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null, tint = AnshCyanSecondary) },
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, null, tint = AnshTextMuted)
                }
            },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().testTag("reg_password_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Password Strength Bar
        Column(modifier = Modifier.fillMaxWidth()) {
            LinearProgressIndicator(
                progress = { strengthFraction },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
                color = if (strengthFraction > 0.8f) AnshEmeraldPrimary else if (strengthFraction > 0.4f) AnshWarningAmber else AnshAlertRed,
                trackColor = AnshGlassBorder
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Min 8 chars, Aa, 123, !@#", fontSize = 10.sp, color = AnshTextMuted)
                Text(
                    text = if (strengthScore >= 5) "Strong" else if (strengthScore >= 3) "Moderate" else "Weak",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (strengthScore >= 5) AnshEmeraldPrimary else AnshWarningAmber
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = confirmPassword,
            onValueChange = { confirmPassword = it },
            label = { Text("Confirm Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().testTag("reg_confirm_password_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AnshEmeraldPrimary, unfocusedBorderColor = AnshGlassBorder, focusedTextColor = AnshTextPrimary, unfocusedTextColor = AnshTextPrimary),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = acceptTerms,
                onCheckedChange = { acceptTerms = it },
                colors = CheckboxDefaults.colors(checkedColor = AnshEmeraldPrimary)
            )
            Text(
                "I accept the ANSH CONNECT Security & Data Privacy Policy.",
                fontSize = 11.sp,
                color = AnshTextSecondary
            )
        }

        if (validationError != null) {
            Text(validationError ?: "", color = AnshAlertRed, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (fullName.isBlank() || username.isBlank() || phone.isBlank() || email.isBlank()) {
                    validationError = "Please fill in all mandatory fields"
                } else if (password != confirmPassword) {
                    validationError = "Passwords do not match"
                } else if (!acceptTerms) {
                    validationError = "You must accept the Security & Privacy Policy"
                } else {
                    viewModel.updateProfile(fullName, "Zero-telemetry user account.", phone, email, gender)
                    onNavigate(ScreenId.MOBILE_OTP)
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("reg_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("PROCEED TO MOBILE OTP", fontWeight = FontWeight.Bold, color = Color.Black)
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun MobileOtpPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var otpCode by remember { mutableStateOf("749201") }
    val cooldown by viewModel.otpCooldown.collectAsState()
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnshTopBar(
            title = "Mobile OTP Verification",
            subtitle = "Step 1 of 3",
            onBackClick = { viewModel.popBackStack() }
        )

        Spacer(modifier = Modifier.height(28.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(AnshCyanSecondary.copy(alpha = 0.15f))
                .border(1.dp, AnshCyanSecondary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Phone, contentDescription = null, tint = AnshCyanSecondary, modifier = Modifier.size(36.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Verify Mobile Number", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("Enter the 6-digit cryptographic token sent to your SMS line", fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = otpCode,
            onValueChange = { if (it.length <= 6) otpCode = it },
            label = { Text("6-Digit OTP") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("mobile_otp_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshEmeraldPrimary,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (cooldown > 0) "Resend code in ${cooldown}s" else "Code ready to resend",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = if (cooldown > 0) AnshTextMuted else AnshEmeraldPrimary
            )
            TextButton(
                onClick = { if (cooldown == 0) viewModel.startOtpCooldown() },
                enabled = cooldown == 0
            ) {
                Text("RESEND OTP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (errorMessage != null) {
            Text(errorMessage ?: "", color = AnshAlertRed, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (otpCode.length == 6) {
                    onNavigate(ScreenId.EMAIL_OTP)
                } else {
                    errorMessage = "Please enter complete 6-digit OTP"
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("mobile_otp_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("VERIFY & CONTINUE TO EMAIL OTP", fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Composable
fun EmailOtpPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var emailCode by remember { mutableStateOf("918234") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnshTopBar(
            title = "Email OTP Verification",
            subtitle = "Step 2 of 3",
            onBackClick = { viewModel.popBackStack() }
        )

        Spacer(modifier = Modifier.height(28.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(AnshEmeraldPrimary.copy(alpha = 0.15f))
                .border(1.dp, AnshEmeraldPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Email, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(36.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Verify Email Identity", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("A secondary authentication token was dispatched to your email address", fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = emailCode,
            onValueChange = { if (it.length <= 6) emailCode = it },
            label = { Text("6-Digit Email Token") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("email_otp_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshEmeraldPrimary,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (emailCode.length == 6) {
                    onNavigate(ScreenId.HUMAN_VERIFICATION)
                } else {
                    errorMessage = "Please enter valid 6-digit email code"
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("email_otp_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("ADVANCE TO HUMAN VERIFICATION", fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}

@Composable
fun HumanVerificationPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val num1 by viewModel.captchaNum1.collectAsState()
    val num2 by viewModel.captchaNum2.collectAsState()
    val input by viewModel.captchaInput.collectAsState()
    val hasError by viewModel.captchaError.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnshTopBar(
            title = "Anti-Bot Verification",
            subtitle = "Step 3 of 3",
            onBackClick = { viewModel.popBackStack() }
        )

        Spacer(modifier = Modifier.height(28.dp))

        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(AnshWarningAmber.copy(alpha = 0.15f))
                .border(1.dp, AnshWarningAmber, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Shield, contentDescription = null, tint = AnshWarningAmber, modifier = Modifier.size(36.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Human Proof Challenge", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("Solve the cryptographic arithmetic equation to activate your profile", fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center)

        Spacer(modifier = Modifier.height(24.dp))

        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("EQUATION CHALLENGE", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "$num1  +  $num2  =  ?",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = AnshEmeraldPrimary
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    IconButton(onClick = { viewModel.regenerateCaptcha() }) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "Regenerate challenge", tint = AnshCyanSecondary)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = input,
            onValueChange = { viewModel.setCaptchaInput(it) },
            label = { Text("Enter Sum Solution") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("captcha_solution_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshEmeraldPrimary,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            ),
            shape = RoundedCornerShape(12.dp)
        )

        if (hasError) {
            Text(
                text = "Incorrect solution. Please recalculate and retry.",
                color = AnshAlertRed,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (viewModel.verifyCaptcha()) {
                    onNavigate(ScreenId.MAIN_DASHBOARD)
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("captcha_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("CONFIRM HUMAN & ENTER DASHBOARD", fontWeight = FontWeight.Bold, color = Color.Black)
        }
    }
}
