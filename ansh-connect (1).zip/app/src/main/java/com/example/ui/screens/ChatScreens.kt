package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.CloudUpload
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DoneAll
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CallType
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.LineReaction
import com.example.data.model.MessageStatus
import com.example.data.model.ScreenId
import com.example.ui.components.AnshBottomBar
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.components.VectorReactionPicker
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun ChattingHubPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val convs by viewModel.conversations.collectAsState()
    var selectedFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }
    var showNewChatDialog by remember { mutableStateOf(false) }

    val filteredConvs = convs.filter { conv ->
        val matchesSearch = conv.title.contains(searchQuery, ignoreCase = true) ||
                conv.lastMessage.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "GROUPS" -> conv.isGroup
            "DIRECT" -> !conv.isGroup
            "PINNED" -> conv.isPinned
            else -> true
        }
        matchesSearch && matchesFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Encrypted Comms",
            subtitle = "Active Threads",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(onClick = { onNavigate(ScreenId.STATUS) }) {
                    Icon(Icons.Outlined.Visibility, contentDescription = "Status Stories", tint = AnshCyanSecondary)
                }
            }
        )

        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search encrypted threads...", fontSize = 12.sp, color = AnshTextMuted) },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null, tint = AnshTextMuted) },
                modifier = Modifier.fillMaxWidth().testTag("chat_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL", "DIRECT", "GROUPS", "PINNED").forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = { Text(filter, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AnshEmeraldPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = AnshEmeraldPrimary,
                            labelColor = AnshTextSecondary
                        )
                    )
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredConvs, key = { it.id }) { conv ->
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openConversation(conv) }
                            .testTag("conversation_card_${conv.id}"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (conv.isGroup) AnshCyanSecondary.copy(alpha = 0.2f) else AnshEmeraldPrimary.copy(alpha = 0.2f))
                                    .border(1.dp, if (conv.isGroup) AnshCyanSecondary else AnshEmeraldPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                if (conv.isGroup) {
                                    Icon(Icons.Outlined.Group, contentDescription = null, tint = AnshCyanSecondary, modifier = Modifier.size(22.dp))
                                } else {
                                    Text(conv.avatarLetter, fontWeight = FontWeight.Bold, color = AnshEmeraldPrimary, fontSize = 16.sp)
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(conv.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                        if (conv.isPinned) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(Icons.Outlined.PushPin, contentDescription = "Pinned", tint = AnshWarningAmber, modifier = Modifier.size(13.dp))
                                        }
                                    }
                                    Text(conv.lastMessageTime, fontSize = 10.sp, color = AnshTextMuted, fontFamily = FontFamily.Monospace)
                                }

                                Spacer(modifier = Modifier.height(2.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        conv.lastMessage,
                                        fontSize = 11.sp,
                                        color = AnshTextSecondary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (conv.unreadCount > 0) {
                                        Box(
                                            modifier = Modifier
                                                .padding(start = 6.dp)
                                                .size(20.dp)
                                                .clip(CircleShape)
                                                .background(AnshEmeraldPrimary),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${conv.unreadCount}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            FloatingActionButton(
                onClick = { showNewChatDialog = true },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(20.dp)
                    .testTag("new_chat_fab"),
                containerColor = AnshEmeraldPrimary
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "New Encrypted Chat", tint = Color.Black)
            }
        }

        if (showNewChatDialog) {
            AlertDialog(
                onDismissRequest = { showNewChatDialog = false },
                title = { Text("Initiate Secure Session", color = AnshTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "Select any contact from your verified directory to initiate an authenticated AES-GCM encrypted channel.",
                        fontSize = 12.sp,
                        color = AnshTextSecondary
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            showNewChatDialog = false
                            onNavigate(ScreenId.CONTACTS)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                    ) {
                        Text("Open Directory", color = Color.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showNewChatDialog = false }) {
                        Text("Cancel", color = AnshTextSecondary)
                    }
                },
                containerColor = AnshObsidianBg
            )
        }

        AnshBottomBar(
            currentScreen = ScreenId.CHATTING,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
fun PrivateChatPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val conv = viewModel.selectedConversation.collectAsState().value
    val allMessages by viewModel.messages.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val convMessages = allMessages[conv?.id].orEmpty()

    var inputText by remember { mutableStateOf("") }
    var showReactionPickerForMsgId by remember { mutableStateOf<String?>(null) }
    var showAttachmentDrawer by remember { mutableStateOf(false) }

    val peerContact = contacts.find { it.fullName == conv?.title }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        // Chat Header with Call shortcuts
        AnshTopBar(
            title = conv?.title ?: "Secure Chat",
            subtitle = "AES-256-GCM • Fingerprint Verified",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(
                    onClick = {
                        val peer = peerContact ?: contacts.first()
                        viewModel.initiateCall(peer, CallType.VOICE)
                    },
                    modifier = Modifier.testTag("chat_voice_call_btn")
                ) {
                    Icon(Icons.Outlined.Call, contentDescription = "Voice Call", tint = AnshEmeraldPrimary)
                }
                IconButton(
                    onClick = {
                        val peer = peerContact ?: contacts.first()
                        viewModel.initiateCall(peer, CallType.VIDEO)
                    },
                    modifier = Modifier.testTag("chat_video_call_btn")
                ) {
                    Icon(Icons.Outlined.Videocam, contentDescription = "Video Call", tint = AnshCyanSecondary)
                }
            }
        )

        // E2EE Security Banner
        Surface(
            color = AnshEmeraldPrimary.copy(alpha = 0.08f),
            modifier = Modifier.fillMaxWidth().border(0.5.dp, AnshEmeraldPrimary.copy(alpha = 0.2f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(13.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "End-to-End Encrypted. No intermediaries or unverified storage.",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AnshEmeraldLight
                )
            }
        }

        // Messages Stream
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            reverseLayout = false
        ) {
            items(convMessages, key = { it.id }) { msg ->
                val isMe = msg.senderId == viewModel.currentUser.value.id
                MessageBubble(
                    message = msg,
                    isMe = isMe,
                    onReactClick = { showReactionPickerForMsgId = msg.id },
                    onDeleteClick = { viewModel.deleteMessage(msg.id) },
                    onPinClick = { viewModel.togglePin(msg.id) },
                    onStarClick = { viewModel.toggleStar(msg.id) }
                )
            }
        }

        // Vector Reaction Picker Tray (Strict zero emoji)
        AnimatedVisibility(visible = showReactionPickerForMsgId != null) {
            VectorReactionPicker(
                onSelectReaction = { reaction ->
                    val msgId = showReactionPickerForMsgId
                    if (msgId != null) {
                        viewModel.toggleReaction(msgId, reaction)
                    }
                    showReactionPickerForMsgId = null
                },
                onDismiss = { showReactionPickerForMsgId = null }
            )
        }

        // Attachment selection drawer
        AnimatedVisibility(visible = showAttachmentDrawer) {
            GlassCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                backgroundColor = AnshObsidianBg
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    AttachmentOption(icon = Icons.Outlined.Description, label = "PDF Doc") {
                        viewModel.sendMessage("", attachmentName = "security_manifest_v2.pdf", attachmentType = "PDF", attachmentSize = "2.1 MB")
                        showAttachmentDrawer = false
                    }
                    AttachmentOption(icon = Icons.Outlined.FolderZip, label = "Encrypted ZIP") {
                        viewModel.sendMessage("", attachmentName = "keys_backup.zip", attachmentType = "ZIP", attachmentSize = "6.4 MB")
                        showAttachmentDrawer = false
                    }
                    AttachmentOption(icon = Icons.Outlined.Videocam, label = "Video Clip") {
                        viewModel.sendMessage("", attachmentName = "packet_capture.mp4", attachmentType = "MP4", attachmentSize = "18.0 MB")
                        showAttachmentDrawer = false
                    }
                }
            }
        }

        // Message Input Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(AnshObsidianBg)
                .border(0.5.dp, AnshGlassBorder.copy(alpha = 0.4f))
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { showAttachmentDrawer = !showAttachmentDrawer },
                modifier = Modifier.testTag("chat_attach_btn")
            ) {
                Icon(Icons.Outlined.AttachFile, contentDescription = "Attach File", tint = AnshCyanSecondary)
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Transmit encrypted message...", fontSize = 12.sp, color = AnshTextMuted) },
                modifier = Modifier.weight(1f).testTag("chat_message_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(20.dp),
                maxLines = 4
            )

            Spacer(modifier = Modifier.width(6.dp))

            if (inputText.isBlank()) {
                IconButton(
                    onClick = {
                        viewModel.sendMessage("Audio encrypted packet [0:12]", attachmentName = "audio_clip.aac", attachmentType = "AUDIO", attachmentSize = "180 KB")
                    },
                    modifier = Modifier.testTag("chat_mic_btn")
                ) {
                    Icon(Icons.Outlined.Mic, contentDescription = "Record Audio", tint = AnshEmeraldPrimary)
                }
            } else {
                IconButton(
                    onClick = {
                        viewModel.sendMessage(inputText)
                        inputText = ""
                    },
                    modifier = Modifier.testTag("chat_send_btn")
                ) {
                    Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Send Message", tint = AnshEmeraldPrimary)
                }
            }
        }
    }
}

@Composable
private fun AttachmentOption(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick).padding(6.dp)) {
        Box(
            modifier = Modifier.size(38.dp).clip(CircleShape).background(AnshCyanSecondary.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = AnshCyanSecondary, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(label, fontSize = 9.sp, color = AnshTextPrimary)
    }
}

@Composable
private fun MessageBubble(
    message: ChatMessage,
    isMe: Boolean,
    onReactClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onPinClick: () -> Unit,
    onStarClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 14.dp,
                        topEnd = 14.dp,
                        bottomStart = if (isMe) 14.dp else 2.dp,
                        bottomEnd = if (isMe) 2.dp else 14.dp
                    )
                )
                .background(if (isMe) AnshEmeraldPrimary.copy(alpha = 0.18f) else AnshGlassBorder.copy(alpha = 0.6f))
                .border(
                    1.dp,
                    if (isMe) AnshEmeraldPrimary.copy(alpha = 0.45f) else AnshGlassBorder,
                    RoundedCornerShape(14.dp)
                )
                .padding(10.dp)
        ) {
            Column {
                if (!isMe) {
                    Text(message.senderName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AnshCyanSecondary)
                    Spacer(modifier = Modifier.height(2.dp))
                }

                if (message.attachmentName != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(AnshObsidianBg.copy(alpha = 0.7f))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Outlined.Description, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(message.attachmentName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary, maxLines = 1)
                            Text("${message.attachmentType} • ${message.attachmentSize}", fontSize = 9.sp, color = AnshTextMuted)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                if (message.content.isNotBlank()) {
                    Text(message.content, fontSize = 13.sp, color = AnshTextPrimary, lineHeight = 17.sp)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.isPinned) {
                        Icon(Icons.Outlined.PushPin, contentDescription = "Pinned", tint = AnshWarningAmber, modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                    }
                    if (message.isStarred) {
                        Icon(Icons.Outlined.Star, contentDescription = "Starred", tint = AnshCyanSecondary, modifier = Modifier.size(11.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                    }
                    Text(message.timestamp, fontSize = 9.sp, color = AnshTextMuted, fontFamily = FontFamily.Monospace)
                    if (isMe) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = if (message.status == MessageStatus.READ) Icons.Outlined.DoneAll else Icons.Outlined.Check,
                            contentDescription = message.status.name,
                            tint = if (message.status == MessageStatus.READ) AnshEmeraldPrimary else AnshTextMuted,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }

        // Strict line reactions row below bubble
        if (message.reactions.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .padding(top = 2.dp, start = 4.dp, end = 4.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(AnshObsidianBg)
                    .border(0.5.dp, AnshGlassBorder, RoundedCornerShape(10.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                message.reactions.forEach { reaction ->
                    Icon(reaction.icon, contentDescription = reaction.label, tint = AnshCyanSecondary, modifier = Modifier.size(12.dp))
                }
            }
        }

        // Micro action buttons
        Row(
            modifier = Modifier.padding(top = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            IconButton(onClick = onReactClick, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Outlined.ThumbUp, contentDescription = "Line React", tint = AnshTextMuted, modifier = Modifier.size(13.dp))
            }
            IconButton(onClick = onPinClick, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Outlined.PushPin, contentDescription = "Pin", tint = AnshTextMuted, modifier = Modifier.size(13.dp))
            }
            IconButton(onClick = onStarClick, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Outlined.Star, contentDescription = "Star", tint = AnshTextMuted, modifier = Modifier.size(13.dp))
            }
            if (isMe) {
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = AnshTextMuted, modifier = Modifier.size(13.dp))
                }
            }
        }
    }
}

@Composable
fun GroupChatPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    // Group chat leverages the same robust messaging mechanism with group header
    PrivateChatPage(viewModel = viewModel, onNavigate = onNavigate)
}

@Composable
fun StatusPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val statuses by viewModel.statusUpdates.collectAsState()
    var newStatusText by remember { mutableStateOf("") }
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Status Network",
            subtitle = "24-Hour Ephemeral Logs",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(onClick = { showCreateDialog = true }) {
                    Icon(Icons.Outlined.Add, contentDescription = "Post Status", tint = AnshEmeraldPrimary)
                }
            }
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text("MY STATUS (24H EPHEMERAL)", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshTextMuted)
            }

            val myStatus = statuses.find { it.isMine }
            if (myStatus != null) {
                item {
                    GlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        borderColor = AnshEmeraldPrimary.copy(alpha = 0.5f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(AnshEmeraldPrimary.copy(alpha = 0.2f))
                                    .border(2.dp, AnshEmeraldPrimary, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Outlined.Security, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(24.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(myStatus.userName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text(myStatus.textSnippet, fontSize = 12.sp, color = AnshTextSecondary)
                                Text("Expires in 23h • ${myStatus.viewersCount} verified viewers", fontSize = 10.sp, color = AnshCyanSecondary)
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text("CONTACT DISPATCHES", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshTextMuted)
            }

            items(statuses.filterNot { it.isMine }, key = { it.id }) { item ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(AnshCyanSecondary.copy(alpha = 0.2f))
                                .border(1.5.dp, if (item.hasUnseen) AnshCyanSecondary else AnshGlassBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(item.userName.take(1), fontWeight = FontWeight.Bold, color = AnshCyanSecondary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.userName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text(item.timestamp, fontSize = 10.sp, color = AnshTextMuted)
                            }
                            Text(item.textSnippet, fontSize = 11.sp, color = AnshTextSecondary)
                        }
                    }
                }
            }
        }

        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Publish Status Log", color = AnshTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("This status will automatically self-destruct after 24 hours.", fontSize = 12.sp, color = AnshTextSecondary)
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = newStatusText,
                            onValueChange = { newStatusText = it },
                            label = { Text("Status text") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AnshEmeraldPrimary,
                                unfocusedBorderColor = AnshGlassBorder,
                                focusedTextColor = AnshTextPrimary,
                                unfocusedTextColor = AnshTextPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newStatusText.isNotBlank()) {
                                viewModel.postStatus(newStatusText)
                                newStatusText = ""
                                showCreateDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                    ) {
                        Text("Post Log", color = Color.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("Cancel", color = AnshTextSecondary)
                    }
                },
                containerColor = AnshObsidianBg
            )
        }

        AnshBottomBar(
            currentScreen = ScreenId.STATUS,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
fun FileSharingPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val files by viewModel.vaultFiles.collectAsState()
    var selectedCategory by remember { mutableStateOf("ALL") }
    var showUploadModal by remember { mutableStateOf(false) }
    var uploadName by remember { mutableStateOf("") }
    var uploadCategory by remember { mutableStateOf("PDF") }

    val filteredFiles = if (selectedCategory == "ALL") files else files.filter { it.category == selectedCategory }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Encrypted Vault",
            subtitle = "Zero-Knowledge Storage",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(onClick = { showUploadModal = true }) {
                    Icon(Icons.Outlined.CloudUpload, contentDescription = "Upload Vault File", tint = AnshEmeraldPrimary)
                }
            }
        )

        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("ALL", "PDF", "ZIP", "DOC", "MP4").forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AnshEmeraldPrimary.copy(alpha = 0.2f),
                            selectedLabelColor = AnshEmeraldPrimary,
                            labelColor = AnshTextSecondary
                        )
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filteredFiles, key = { it.id }) { item ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(AnshCyanSecondary.copy(alpha = 0.15f))
                                .border(1.dp, AnshCyanSecondary.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(item.extension, fontSize = 10.sp, fontWeight = FontWeight.Black, color = AnshCyanSecondary)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.fileName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary, maxLines = 1)
                            Text("${item.sizeText} • Uploaded ${item.uploadedAt}", fontSize = 10.sp, color = AnshTextMuted)
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { item.downloadProgress },
                                modifier = Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)),
                                color = AnshEmeraldPrimary,
                                trackColor = AnshGlassBorder
                            )
                        }

                        IconButton(onClick = { /* simulated download */ }) {
                            Icon(Icons.Outlined.CloudDownload, contentDescription = "Download File", tint = AnshEmeraldPrimary)
                        }
                    }
                }
            }
        }

        if (showUploadModal) {
            AlertDialog(
                onDismissRequest = { showUploadModal = false },
                title = { Text("Upload Encrypted File", color = AnshTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = uploadName,
                            onValueChange = { uploadName = it },
                            label = { Text("File Name (e.g. audit_keys.pdf)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AnshEmeraldPrimary,
                                unfocusedBorderColor = AnshGlassBorder,
                                focusedTextColor = AnshTextPrimary,
                                unfocusedTextColor = AnshTextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Category: PDF, ZIP, DOC, XLS, MP4", fontSize = 11.sp, color = AnshTextSecondary)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (uploadName.isNotBlank()) {
                                viewModel.uploadVaultFile(uploadName, uploadCategory, "4.2 MB")
                                uploadName = ""
                                showUploadModal = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                    ) {
                        Text("Upload File", color = Color.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUploadModal = false }) {
                        Text("Cancel", color = AnshTextSecondary)
                    }
                },
                containerColor = AnshObsidianBg
            )
        }

        AnshBottomBar(
            currentScreen = ScreenId.FILE_SHARING,
            onSelectScreen = onNavigate
        )
    }
}
