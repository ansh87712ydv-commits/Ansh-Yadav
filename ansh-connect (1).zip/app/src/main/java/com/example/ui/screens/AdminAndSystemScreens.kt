package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CloudSync
import androidx.compose.material.icons.outlined.Dangerous
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Report
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NetworkStatusState
import com.example.data.model.ScreenId
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun AdminLoginPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var adminToken by remember { mutableStateOf("ANSH-SUPER-ADMIN-9981") }
    var secretKey by remember { mutableStateOf("••••••••••••••••") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(AnshAlertRed.copy(alpha = 0.15f))
                .border(1.dp, AnshAlertRed, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.AdminPanelSettings, contentDescription = null, tint = AnshAlertRed, modifier = Modifier.size(36.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Restricted Admin Console", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("Authorized Root Personnel Only • System Logged", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = AnshAlertRed)

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = adminToken,
            onValueChange = { adminToken = it },
            label = { Text("Master Admin Token") },
            modifier = Modifier.fillMaxWidth().testTag("admin_token_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshAlertRed,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = secretKey,
            onValueChange = { secretKey = it },
            label = { Text("Hardware YubiKey / Secret") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth().testTag("admin_secret_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AnshAlertRed,
                unfocusedBorderColor = AnshGlassBorder,
                focusedTextColor = AnshTextPrimary,
                unfocusedTextColor = AnshTextPrimary
            )
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (adminToken.isNotBlank()) {
                    onNavigate(ScreenId.ADMIN_DASHBOARD)
                } else {
                    error = "Invalid admin token"
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("admin_login_submit_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = AnshAlertRed),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("AUTHORIZE PRIVILEGED SESSION", fontWeight = FontWeight.Bold, color = Color.White)
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(onClick = { viewModel.popBackStack() }) {
            Text("Return to User Workspace", color = AnshTextSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
fun AdminDashboardPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val auditLogs by viewModel.auditLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Admin Telemetry",
            subtitle = "Root Operations Center",
            onBackClick = { viewModel.popBackStack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Metrics Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminMetric(modifier = Modifier.weight(1f), icon = Icons.Outlined.People, title = "AGENTS", value = "2,410", color = AnshEmeraldPrimary)
                AdminMetric(modifier = Modifier.weight(1f), icon = Icons.Outlined.Speed, title = "CPU LOAD", value = "18%", color = AnshCyanSecondary)
                AdminMetric(modifier = Modifier.weight(1f), icon = Icons.Outlined.Memory, title = "RAM ALLOC", value = "3.2 GB", color = AnshWarningAmber)
                AdminMetric(modifier = Modifier.weight(1f), icon = Icons.Outlined.Storage, title = "STORAGE", value = "42%", color = AnshEmeraldLight)
            }

            // Quick Nav Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onNavigate(ScreenId.USER_MANAGEMENT) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = AnshCyanSecondary)
                ) {
                    Text("Users", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Button(
                    onClick = { onNavigate(ScreenId.REPORTS_MODERATION) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = AnshWarningAmber)
                ) {
                    Text("Moderation", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                Button(
                    onClick = { onNavigate(ScreenId.MAINTENANCE) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = AnshAlertRed)
                ) {
                    Text("Maint Mode", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            // Security Audit Logs
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("SECURITY INCIDENT & AUDIT FEED", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshTextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    auditLogs.forEach { log ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (log.isHighRisk) Icons.Outlined.Warning else Icons.Outlined.Security,
                                contentDescription = null,
                                tint = if (log.isHighRisk) AnshAlertRed else AnshEmeraldPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(log.event, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text("${log.ipAddress} • ${log.device} • ${log.timestamp}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminMetric(modifier: Modifier, icon: ImageVector, title: String, value: String, color: Color) {
    GlassCard(modifier = modifier, shape = RoundedCornerShape(12.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 16.sp, fontWeight = FontWeight.Black, color = color)
            Text(title, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
        }
    }
}

@Composable
fun UserManagementPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val contacts by viewModel.contacts.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "User Directory & Moderation",
            subtitle = "Agent Governance",
            onBackClick = { viewModel.popBackStack() }
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(contacts, key = { it.id }) { user ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(user.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                if (user.isBlocked) {
                                    Text("[SUSPENDED]", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshAlertRed)
                                } else {
                                    Text("[ACTIVE]", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshEmeraldPrimary)
                                }
                            }
                            Text("@${user.username} • ${user.phone}", fontSize = 10.sp, color = AnshTextMuted)
                        }

                        if (user.isBlocked) {
                            Button(
                                onClick = { viewModel.unblockUser(user.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                            ) {
                                Text("Reactivate", fontSize = 10.sp, color = Color.Black)
                            }
                        } else {
                            Button(
                                onClick = { viewModel.blockUser(user.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = AnshAlertRed)
                            ) {
                                Text("Suspend", fontSize = 10.sp, color = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReportsModerationPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val reports by viewModel.moderationReports.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Reports & Abuse Queue",
            subtitle = "${reports.size} Open Cases",
            onBackClick = { viewModel.popBackStack() }
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(reports, key = { it.id }) { rep ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Target: ${rep.targetUser}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshAlertRed)
                            Text(rep.timestamp, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                        }
                        Text("Reported by ${rep.reportedBy}: ${rep.reason}", fontSize = 11.sp, color = AnshTextSecondary, modifier = Modifier.padding(vertical = 4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.dismissReport(rep.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Resolve Case", fontSize = 10.sp, color = Color.Black)
                            }
                            OutlinedButton(
                                onClick = { viewModel.dismissReport(rep.id) },
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text("Dismiss", fontSize = 10.sp, color = AnshTextSecondary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Error404Page(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    ErrorScaffold(
        code = "404",
        title = "Route Not Found",
        desc = "The cryptographic endpoint you navigated to does not exist or was rotated.",
        onHomeClick = { onNavigate(ScreenId.MAIN_DASHBOARD) },
        onRetryClick = { viewModel.popBackStack() }
    )
}

@Composable
fun Error500Page(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    ErrorScaffold(
        code = "500",
        title = "Internal Enclave Error",
        desc = "Upstream server node encountered an unhandled exception. Stack trace suppressed for security.",
        onHomeClick = { onNavigate(ScreenId.MAIN_DASHBOARD) },
        onRetryClick = { onNavigate(ScreenId.MAIN_DASHBOARD) }
    )
}

@Composable
fun Error502Page(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    ErrorScaffold(
        code = "502",
        title = "Bad Gateway Handshake",
        desc = "The edge proxy received an invalid response from the internal messaging relay.",
        onHomeClick = { onNavigate(ScreenId.MAIN_DASHBOARD) },
        onRetryClick = { onNavigate(ScreenId.MAIN_DASHBOARD) }
    )
}

@Composable
fun NetworkErrorPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.WifiOff, contentDescription = null, tint = AnshAlertRed, modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Network Disconnected", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("No cellular or Wi-Fi uplink detected. Cryptographic messages are queued locally in encrypted memory buffer.", fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                viewModel.setNetworkStatus(NetworkStatusState.CONNECTED)
                viewModel.popBackStack()
            },
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Outlined.Refresh, contentDescription = null, tint = Color.Black)
            Spacer(modifier = Modifier.width(8.dp))
            Text("RECONNECT TO CLOUD NODES", color = Color.Black, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedButton(onClick = { viewModel.popBackStack() }) {
            Text("Use Offline Vault Mode", color = AnshTextSecondary)
        }
    }
}

@Composable
fun MaintenancePage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Outlined.CloudSync, contentDescription = null, tint = AnshWarningAmber, modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Scheduled Maintenance", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("Upgrading cryptographic ciphers across core European & Asian clusters. Resuming in 00:44:12.", fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { onNavigate(ScreenId.MAIN_DASHBOARD) },
            colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
        ) {
            Text("Check Node Status", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ErrorScaffold(
    code: String,
    title: String,
    desc: String,
    onHomeClick: () -> Unit,
    onRetryClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(code, fontSize = 72.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = AnshAlertRed)
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Spacer(modifier = Modifier.height(8.dp))
        Text(desc, fontSize = 12.sp, color = AnshTextSecondary, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(modifier = Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = onHomeClick, colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)) {
                Text("Dashboard", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(onClick = onRetryClick) {
                Text("Retry Handshake", color = AnshTextPrimary)
            }
        }
    }
}
