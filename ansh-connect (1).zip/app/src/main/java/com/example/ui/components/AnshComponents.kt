package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FolderShared
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PhoneInTalk
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LineReaction
import com.example.data.model.NetworkStatusState
import com.example.data.model.ScreenId
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshGlassCard
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(16.dp),
    borderColor: Color = AnshGlassBorder.copy(alpha = 0.5f),
    backgroundColor: Color = AnshGlassCard,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(backgroundColor)
            .border(1.dp, borderColor, shape)
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun AnshTopBar(
    title: String,
    subtitle: String? = null,
    showBack: Boolean = true,
    onBackClick: () -> Unit = {},
    networkStatus: NetworkStatusState = NetworkStatusState.CONNECTED,
    actions: @Composable () -> Unit = {}
) {
    Surface(
        color = AnshObsidianBg.copy(alpha = 0.95f),
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .border(width = 0.5.dp, color = AnshGlassBorder.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                if (showBack) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("top_bar_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "Navigate Back",
                            tint = AnshTextPrimary
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(AnshEmeraldPrimary.copy(alpha = 0.2f), AnshCyanSecondary.copy(alpha = 0.2f))
                                )
                            )
                            .border(1.dp, AnshEmeraldPrimary.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Security,
                            contentDescription = "Security Shield",
                            tint = AnshEmeraldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }

                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AnshTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = "Encrypted Channel",
                            tint = AnshEmeraldPrimary,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                    if (subtitle != null) {
                        Text(
                            text = subtitle,
                            fontSize = 11.sp,
                            color = AnshTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        NetworkIndicatorMini(status = networkStatus)
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                actions()
            }
        }
    }
}

@Composable
fun NetworkIndicatorMini(status: NetworkStatusState) {
    val (dotColor, text) = when (status) {
        NetworkStatusState.CONNECTED -> AnshEmeraldPrimary to "E2EE ENCRYPTED • ONLINE"
        NetworkStatusState.SLOW -> AnshWarningAmber to "HIGH LATENCY (240ms)"
        NetworkStatusState.RECONNECTING -> AnshCyanSecondary to "RENEGOTIATING HANDSHAKE..."
        NetworkStatusState.DISCONNECTED -> AnshAlertRed to "OFFLINE BUFFERED"
    }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = text,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            color = dotColor,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun AnshBottomBar(
    currentScreen: ScreenId,
    onSelectScreen: (ScreenId) -> Unit
) {
    Surface(
        color = AnshObsidianBg.copy(alpha = 0.98f),
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .border(width = 0.5.dp, color = AnshGlassBorder.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = Icons.Outlined.Dashboard,
                label = "Dashboard",
                isSelected = currentScreen == ScreenId.MAIN_DASHBOARD,
                onClick = { onSelectScreen(ScreenId.MAIN_DASHBOARD) }
            )
            BottomNavItem(
                icon = Icons.Outlined.ChatBubbleOutline,
                label = "Chats",
                isSelected = currentScreen in listOf(ScreenId.CHATTING, ScreenId.PRIVATE_CHAT, ScreenId.GROUP_CHAT),
                onClick = { onSelectScreen(ScreenId.CHATTING) }
            )
            BottomNavItem(
                icon = Icons.Outlined.Call,
                label = "Calls",
                isSelected = currentScreen in listOf(ScreenId.CALL_HISTORY, ScreenId.VOICE_CALLING, ScreenId.VIDEO_CALLING),
                onClick = { onSelectScreen(ScreenId.CALL_HISTORY) }
            )
            BottomNavItem(
                icon = Icons.Outlined.People,
                label = "Contacts",
                isSelected = currentScreen in listOf(ScreenId.CONTACTS, ScreenId.CONTACT_REQUESTS),
                onClick = { onSelectScreen(ScreenId.CONTACTS) }
            )
            BottomNavItem(
                icon = Icons.Outlined.FolderShared,
                label = "Vault",
                isSelected = currentScreen == ScreenId.FILE_SHARING,
                onClick = { onSelectScreen(ScreenId.FILE_SHARING) }
            )
            BottomNavItem(
                icon = Icons.Outlined.Settings,
                label = "Settings",
                isSelected = currentScreen in listOf(ScreenId.SETTINGS, ScreenId.PRIVACY_SECURITY, ScreenId.USER_PROFILE),
                onClick = { onSelectScreen(ScreenId.SETTINGS) }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = AnshEmeraldPrimary
    val inactiveColor = AnshTextMuted

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("nav_item_${label.lowercase()}")
    ) {
        Box(
            modifier = Modifier
                .size(if (isSelected) 32.dp else 28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) activeColor.copy(alpha = 0.15f) else Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) activeColor else inactiveColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) activeColor else inactiveColor
        )
    }
}

/**
 * Strict Line Reactions Bar - Zero Emojis
 */
@Composable
fun VectorReactionPicker(
    onSelectReaction: (LineReaction) -> Unit,
    onDismiss: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        backgroundColor = AnshObsidianBg.copy(alpha = 0.95f),
        borderColor = AnshEmeraldPrimary.copy(alpha = 0.4f)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LineReaction.values().forEach { reaction ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSelectReaction(reaction) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = reaction.icon,
                        contentDescription = reaction.label,
                        tint = AnshCyanSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = reaction.label,
                        fontSize = 9.sp,
                        color = AnshTextSecondary
                    )
                }
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                Icon(
                    imageVector = Icons.Outlined.Close,
                    contentDescription = "Close Picker",
                    tint = AnshTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Permission Explanation & Action Modal
 */
@Composable
fun PermissionDialog(
    permissionType: String,
    onDismiss: () -> Unit,
    onGrantRealHardware: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Security,
                    contentDescription = "Hardware Permission",
                    tint = AnshEmeraldPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Hardware Access Protocol",
                    color = AnshTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "ANSH CONNECT requires direct hardware permissions to function securely without unverified intermediaries:",
                    color = AnshTextSecondary,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                PermissionItem(
                    icon = Icons.Outlined.Videocam,
                    title = "Camera (android.permission.CAMERA)",
                    desc = "End-to-end encrypted video streaming & QR identity handshakes."
                )
                PermissionItem(
                    icon = Icons.Outlined.PhoneInTalk,
                    title = "Microphone (android.permission.RECORD_AUDIO)",
                    desc = "Opus encrypted voice calling & high-fidelity audio packets."
                )
                PermissionItem(
                    icon = Icons.Outlined.People,
                    title = "Contacts (android.permission.READ_CONTACTS)",
                    desc = "Zero-cloud local cryptographic contact verification."
                )
                PermissionItem(
                    icon = Icons.Outlined.Notifications,
                    title = "Notifications & Overlays",
                    desc = "High-priority incoming call displays over other applications."
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onGrantRealHardware()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
            ) {
                Text("Authorize Access", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Dismiss", color = AnshTextSecondary)
            }
        },
        containerColor = AnshObsidianBg,
        tonalElevation = 8.dp
    )
}

@Composable
private fun PermissionItem(icon: ImageVector, title: String, desc: String) {
    Row(modifier = Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AnshCyanSecondary,
            modifier = Modifier
                .size(18.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = AnshTextPrimary)
            Text(text = desc, fontSize = 10.sp, color = AnshTextMuted)
        }
    }
}
