package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.FolderShared
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.QrCode
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Gender
import com.example.data.model.NetworkStatusState
import com.example.data.model.ScreenId
import com.example.ui.components.AnshBottomBar
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun MainDashboardPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()
    val convs by viewModel.conversations.collectAsState()
    val calls by viewModel.callRecords.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val vaultFiles by viewModel.vaultFiles.collectAsState()
    val networkStatus by viewModel.networkStatus.collectAsState()

    val totalUnread = convs.sumOf { it.unreadCount }
    val onlineContactsCount = contacts.count { it.isOnline }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "ANSH DASHBOARD",
            subtitle = "Security Hub • Online",
            showBack = false,
            networkStatus = networkStatus,
            actions = {
                IconButton(onClick = { onNavigate(ScreenId.NOTIFICATION) }) {
                    Icon(Icons.Outlined.Notifications, contentDescription = "Alerts", tint = AnshCyanSecondary)
                }
                IconButton(onClick = { onNavigate(ScreenId.USER_PROFILE) }) {
                    Icon(Icons.Outlined.Person, contentDescription = "Profile", tint = AnshEmeraldPrimary)
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Agent Security Badge Card
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = AnshEmeraldPrimary.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(AnshEmeraldPrimary.copy(alpha = 0.25f), AnshCyanSecondary.copy(alpha = 0.25f))
                                )
                            )
                            .border(1.5.dp, AnshEmeraldPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.fullName.take(2).uppercase(),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = AnshEmeraldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = user.fullName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = AnshTextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = "Verified Identity",
                                tint = AnshEmeraldPrimary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Text(
                            text = "@${user.username} • Tier: ${user.securityTier.name}",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AnshCyanSecondary
                        )
                        Text(
                            text = "Key: ${user.publicKeyFingerprint.take(22)}...",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = AnshTextMuted
                        )
                    }

                    IconButton(onClick = { onNavigate(ScreenId.USER_PROFILE) }) {
                        Icon(Icons.Outlined.QrCode, contentDescription = "Identity QR", tint = AnshTextPrimary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Metric Gauges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricWidget(
                    modifier = Modifier.weight(1f),
                    title = "UNREAD",
                    value = "$totalUnread",
                    tint = if (totalUnread > 0) AnshEmeraldPrimary else AnshTextMuted,
                    onClick = { onNavigate(ScreenId.CHATTING) }
                )
                MetricWidget(
                    modifier = Modifier.weight(1f),
                    title = "ONLINE",
                    value = "$onlineContactsCount",
                    tint = AnshCyanSecondary,
                    onClick = { onNavigate(ScreenId.CONTACTS) }
                )
                MetricWidget(
                    modifier = Modifier.weight(1f),
                    title = "CALLS",
                    value = "${calls.size}",
                    tint = AnshWarningAmber,
                    onClick = { onNavigate(ScreenId.CALL_HISTORY) }
                )
                MetricWidget(
                    modifier = Modifier.weight(1f),
                    title = "VAULT",
                    value = "${vaultFiles.size}",
                    tint = AnshEmeraldLight,
                    onClick = { onNavigate(ScreenId.FILE_SHARING) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Launcher Grid
            Text("COMMAND LAUNCHPAD", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionLauncherButton(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.ChatBubbleOutline,
                    label = "Messages",
                    color = AnshEmeraldPrimary,
                    onClick = { onNavigate(ScreenId.CHATTING) }
                )
                ActionLauncherButton(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Call,
                    label = "Voice Call",
                    color = AnshCyanSecondary,
                    onClick = {
                        val peer = contacts.firstOrNull()
                        if (peer != null) viewModel.initiateCall(peer, com.example.data.model.CallType.VOICE)
                    }
                )
                ActionLauncherButton(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Videocam,
                    label = "Video Call",
                    color = AnshEmeraldLight,
                    onClick = {
                        val peer = contacts.firstOrNull()
                        if (peer != null) viewModel.initiateCall(peer, com.example.data.model.CallType.VIDEO)
                    }
                )
                ActionLauncherButton(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Security,
                    label = "Perms",
                    color = AnshWarningAmber,
                    onClick = { viewModel.requestPermissions("ALL") }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Recent Conversations Preview
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SECURE THREADS", fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                TextButton(onClick = { onNavigate(ScreenId.CHATTING) }) {
                    Text("View All", fontSize = 11.sp, color = AnshCyanSecondary)
                }
            }

            convs.take(3).forEach { conv ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { viewModel.openConversation(conv) },
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AnshGlassBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(conv.avatarLetter, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(conv.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text(conv.lastMessageTime, fontSize = 10.sp, color = AnshTextMuted)
                            }
                            Text(
                                conv.lastMessage,
                                fontSize = 11.sp,
                                color = AnshTextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Network Simulation & Diagnostics Hub
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("NETWORK RESILIENCE CONTROLLER", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshTextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Simulate system states for verification:", fontSize = 11.sp, color = AnshTextSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.setNetworkStatus(NetworkStatusState.CONNECTED) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Online", fontSize = 10.sp, color = AnshEmeraldPrimary)
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel.setNetworkStatus(NetworkStatusState.DISCONNECTED)
                                onNavigate(ScreenId.NETWORK_ERROR)
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Drop", fontSize = 10.sp, color = AnshAlertRed)
                        }
                        OutlinedButton(
                            onClick = { onNavigate(ScreenId.ERROR_404) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("404", fontSize = 10.sp, color = AnshTextSecondary)
                        }
                        OutlinedButton(
                            onClick = { onNavigate(ScreenId.ADMIN_DASHBOARD) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Admin", fontSize = 10.sp, color = AnshCyanSecondary)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        AnshBottomBar(
            currentScreen = ScreenId.MAIN_DASHBOARD,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
private fun MetricWidget(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    tint: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = tint)
            Spacer(modifier = Modifier.height(2.dp))
            Text(title, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
        }
    }
}

@Composable
private fun ActionLauncherButton(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    GlassCard(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = AnshTextPrimary)
        }
    }
}

@Composable
fun UserProfilePage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Identity Profile",
            subtitle = "Cryptographic Credentials",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(onClick = { onNavigate(ScreenId.EDIT_PROFILE) }) {
                    Icon(Icons.Outlined.Edit, contentDescription = "Edit Profile", tint = AnshCyanSecondary)
                }
            }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large Avatar
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(AnshEmeraldPrimary.copy(alpha = 0.2f), AnshCyanSecondary.copy(alpha = 0.2f))
                        )
                    )
                    .border(2.dp, AnshEmeraldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = user.fullName.take(2).uppercase(),
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = AnshEmeraldPrimary
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(user.fullName, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
            Text("@${user.username} • Verified", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = AnshEmeraldLight)
            Text(user.bio, fontSize = 12.sp, color = AnshTextSecondary, modifier = Modifier.padding(top = 4.dp))

            Spacer(modifier = Modifier.height(20.dp))

            // Security Fingerprint Card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Fingerprint, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PUBLIC KEY FINGERPRINT", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = user.publicKeyFingerprint,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AnshCyanSecondary,
                        lineHeight = 15.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Verified with SHA256 • Curve25519 Identity", fontSize = 9.sp, color = AnshTextMuted)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Details card
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    DetailRow(label = "Mobile Identity", value = user.phone)
                    DetailRow(label = "Registered Email", value = user.email)
                    DetailRow(label = "Date of Birth", value = user.dob)
                    DetailRow(label = "Gender", value = user.gender.name)
                    DetailRow(label = "System Role", value = user.role.name)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { onNavigate(ScreenId.EDIT_PROFILE) },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Outlined.Edit, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("EDIT PROFILE DETAILS", fontWeight = FontWeight.Bold, color = Color.Black)
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = { onNavigate(ScreenId.WELCOME) },
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Outlined.Logout, contentDescription = null, tint = AnshAlertRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("DISCONNECT SESSION & LOGOUT", color = AnshAlertRed)
            }
        }

        AnshBottomBar(
            currentScreen = ScreenId.USER_PROFILE,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = AnshTextSecondary)
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = AnshTextPrimary)
    }
}

@Composable
fun EditProfilePage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()

    var fullName by remember { mutableStateOf(user.fullName) }
    var bio by remember { mutableStateOf(user.bio) }
    var phone by remember { mutableStateOf(user.phone) }
    var email by remember { mutableStateOf(user.email) }
    var gender by remember { mutableStateOf(user.gender) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Edit Profile",
            subtitle = "Modify Local Credentials",
            onBackClick = { viewModel.popBackStack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = fullName,
                onValueChange = { fullName = it },
                label = { Text("Full Legal Name") },
                modifier = Modifier.fillMaxWidth().testTag("edit_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = bio,
                onValueChange = { bio = it },
                label = { Text("Status Bio") },
                modifier = Modifier.fillMaxWidth().testTag("edit_bio_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Mobile Number") },
                modifier = Modifier.fillMaxWidth().testTag("edit_phone_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                modifier = Modifier.fillMaxWidth().testTag("edit_email_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text("Gender Identity", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Gender.values().forEach { g ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = gender == g,
                            onClick = { gender = g },
                            colors = RadioButtonDefaults.colors(selectedColor = AnshEmeraldPrimary)
                        )
                        Text(g.name.take(4), fontSize = 11.sp, color = AnshTextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    viewModel.updateProfile(fullName, bio, phone, email, gender)
                    viewModel.popBackStack()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_profile_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("SAVE PROFILE CHANGES", fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}
