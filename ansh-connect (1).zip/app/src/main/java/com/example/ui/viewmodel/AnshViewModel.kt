package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CallState
import com.example.data.model.CallType
import com.example.data.model.ContactItem
import com.example.data.model.Conversation
import com.example.data.model.Gender
import com.example.data.model.LineReaction
import com.example.data.model.NetworkStatusState
import com.example.data.model.ScreenId
import com.example.data.repository.AnshRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AnshViewModel(
    private val repository: AnshRepository = AnshRepository()
) : ViewModel() {

    // Screen State & Navigation Stack
    private val _currentScreen = MutableStateFlow(ScreenId.WELCOME)
    val currentScreen: StateFlow<ScreenId> = _currentScreen.asStateFlow()

    private val backStack = mutableListOf<ScreenId>()

    // Selected conversation
    private val _selectedConversation = MutableStateFlow<Conversation?>(null)
    val selectedConversation: StateFlow<Conversation?> = _selectedConversation.asStateFlow()

    // Call duration timer
    private val _callSeconds = MutableStateFlow(0)
    val callSeconds: StateFlow<Int> = _callSeconds.asStateFlow()
    private var callTimerJob: Job? = null

    // OTP Timers
    private val _otpCooldown = MutableStateFlow(60)
    val otpCooldown: StateFlow<Int> = _otpCooldown.asStateFlow()
    private var otpTimerJob: Job? = null

    // Human Verification Challenge State
    private val _captchaNum1 = MutableStateFlow(14)
    val captchaNum1: StateFlow<Int> = _captchaNum1.asStateFlow()
    private val _captchaNum2 = MutableStateFlow(8)
    val captchaNum2: StateFlow<Int> = _captchaNum2.asStateFlow()
    private val _captchaInput = MutableStateFlow("")
    val captchaInput: StateFlow<String> = _captchaInput.asStateFlow()
    private val _captchaError = MutableStateFlow(false)
    val captchaError: StateFlow<Boolean> = _captchaError.asStateFlow()

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Permission Dialog State
    private val _showPermissionModal = MutableStateFlow(false)
    val showPermissionModal: StateFlow<Boolean> = _showPermissionModal.asStateFlow()
    private val _permissionTypeRequested = MutableStateFlow("ALL") // "CAMERA", "AUDIO", "CONTACTS", "ALL"
    val permissionTypeRequested: StateFlow<String> = _permissionTypeRequested.asStateFlow()

    // Repository flows exposed directly
    val currentUser = repository.currentUser
    val networkStatus = repository.networkStatus
    val conversations = repository.conversations
    val messages = repository.messages
    val contacts = repository.contacts
    val contactRequests = repository.contactRequests
    val callRecords = repository.callRecords
    val statusUpdates = repository.statusUpdates
    val vaultFiles = repository.vaultFiles
    val notifications = repository.notifications
    val auditLogs = repository.auditLogs
    val moderationReports = repository.moderationReports
    val activeCallState = repository.activeCallState
    val activeCallPeer = repository.activeCallPeer
    val activeCallType = repository.activeCallType
    val isMuted = repository.isMuted
    val isSpeakerOn = repository.isSpeakerOn
    val isCameraOff = repository.isCameraOff

    init {
        startOtpCooldown()
    }

    fun navigateTo(screen: ScreenId) {
        if (_currentScreen.value != screen) {
            backStack.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun popBackStack(): Boolean {
        return if (backStack.isNotEmpty()) {
            _currentScreen.value = backStack.removeAt(backStack.size - 1)
            true
        } else {
            if (_currentScreen.value != ScreenId.MAIN_DASHBOARD && _currentScreen.value != ScreenId.WELCOME) {
                _currentScreen.value = ScreenId.MAIN_DASHBOARD
                true
            } else {
                false
            }
        }
    }

    fun openConversation(conversation: Conversation) {
        _selectedConversation.value = conversation
        if (conversation.isGroup) {
            navigateTo(ScreenId.GROUP_CHAT)
        } else {
            navigateTo(ScreenId.PRIVATE_CHAT)
        }
    }

    fun sendMessage(text: String, attachmentName: String? = null, attachmentType: String? = null, attachmentSize: String? = null) {
        val conv = _selectedConversation.value ?: return
        repository.sendMessage(conv.id, text, attachmentName, attachmentType, attachmentSize)
    }

    fun toggleReaction(messageId: String, reaction: LineReaction) {
        val conv = _selectedConversation.value ?: return
        repository.toggleReaction(conv.id, messageId, reaction)
    }

    fun togglePin(messageId: String) {
        val conv = _selectedConversation.value ?: return
        repository.togglePinMessage(conv.id, messageId)
    }

    fun toggleStar(messageId: String) {
        val conv = _selectedConversation.value ?: return
        repository.toggleStarMessage(conv.id, messageId)
    }

    fun deleteMessage(messageId: String) {
        val conv = _selectedConversation.value ?: return
        repository.deleteMessage(conv.id, messageId)
    }

    fun initiateCall(peer: ContactItem, type: CallType) {
        repository.startCall(peer, type)
        _callSeconds.value = 0
        if (type == CallType.VOICE) {
            navigateTo(ScreenId.VOICE_CALLING)
        } else {
            navigateTo(ScreenId.VIDEO_CALLING)
        }
        viewModelScope.launch {
            delay(1500)
            repository.connectCall()
            startCallTimer()
        }
    }

    private fun startCallTimer() {
        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (repository.activeCallState.value == CallState.CONNECTED) {
                delay(1000)
                _callSeconds.update { it + 1 }
            }
        }
    }

    fun terminateCall() {
        callTimerJob?.cancel()
        repository.endCall()
        popBackStack()
    }

    fun toggleMute() = repository.toggleMute()
    fun toggleSpeaker() = repository.toggleSpeaker()
    fun toggleCamera() = repository.toggleCamera()

    fun startOtpCooldown() {
        _otpCooldown.value = 60
        otpTimerJob?.cancel()
        otpTimerJob = viewModelScope.launch {
            while (_otpCooldown.value > 0) {
                delay(1000)
                _otpCooldown.update { it - 1 }
            }
        }
    }

    fun setCaptchaInput(input: String) {
        _captchaInput.value = input
        _captchaError.value = false
    }

    fun verifyCaptcha(): Boolean {
        val expected = _captchaNum1.value + _captchaNum2.value
        val isCorrect = _captchaInput.value.trim().toIntOrNull() == expected
        if (isCorrect) {
            _captchaError.value = false
            navigateTo(ScreenId.MAIN_DASHBOARD)
            return true
        } else {
            _captchaError.value = true
            return false
        }
    }

    fun regenerateCaptcha() {
        _captchaNum1.value = (10..30).random()
        _captchaNum2.value = (3..15).random()
        _captchaInput.value = ""
        _captchaError.value = false
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun requestPermissions(type: String = "ALL") {
        _permissionTypeRequested.value = type
        _showPermissionModal.value = true
    }

    fun dismissPermissionModal() {
        _showPermissionModal.value = false
    }

    fun addContact(name: String, username: String, phone: String, email: String) {
        repository.addContact(name, username, phone, email)
    }

    fun blockUser(contactId: String) = repository.blockUser(contactId)
    fun unblockUser(contactId: String) = repository.unblockUser(contactId)
    fun acceptRequest(reqId: String) = repository.acceptContactRequest(reqId)
    fun rejectRequest(reqId: String) = repository.rejectContactRequest(reqId)

    fun uploadVaultFile(name: String, category: String, sizeText: String) {
        repository.uploadVaultFile(name, category, sizeText)
    }

    fun postStatus(caption: String) = repository.postStatus(caption)
    fun updateProfile(fullName: String, bio: String, phone: String, email: String, gender: Gender) {
        repository.updateProfile(fullName, bio, phone, email, gender)
    }

    fun toggle2FA() = repository.toggleTwoFactor()
    fun toggleBiometric() = repository.toggleBiometric()
    fun toggleReadReceipts() = repository.toggleReadReceipts()
    fun toggleLastSeen() = repository.toggleLastSeen()
    fun setNetworkStatus(status: NetworkStatusState) = repository.setNetworkStatus(status)
    fun dismissReport(reportId: String) = repository.dismissReport(reportId)
}
