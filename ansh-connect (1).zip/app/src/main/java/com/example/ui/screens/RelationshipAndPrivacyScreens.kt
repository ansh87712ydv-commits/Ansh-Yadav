package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CallType
import com.example.data.model.ScreenId
import com.example.ui.components.AnshBottomBar
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun ContactsPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val contacts by viewModel.contacts.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    var newName by remember { mutableStateOf("") }
    var newUsername by remember { mutableStateOf("") }
    var newPhone by remember { mutableStateOf("") }
    var newEmail by remember { mutableStateOf("") }

    val activeContacts = contacts.filterNot { it.isBlocked }.filter {
        it.fullName.contains(searchQuery, ignoreCase = true) || it.username.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Secure Contacts",
            subtitle = "${activeContacts.size} Authenticated Peers",
            onBackClick = { viewModel.popBackStack() },
            actions = {
                IconButton(onClick = { onNavigate(ScreenId.CONTACT_REQUESTS) }) {
                    Icon(Icons.Outlined.PersonAdd, contentDescription = "Pending Requests", tint = AnshCyanSecondary)
                }
                IconButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Outlined.PersonAdd, contentDescription = "Add Contact", tint = AnshEmeraldPrimary)
                }
            }
        )

        Column(modifier = Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Search by name or @handle") },
                modifier = Modifier.fillMaxWidth().testTag("contact_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AnshEmeraldPrimary,
                    unfocusedBorderColor = AnshGlassBorder,
                    focusedTextColor = AnshTextPrimary,
                    unfocusedTextColor = AnshTextPrimary
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(activeContacts, key = { it.id }) { c ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(AnshGlassBorder),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(c.avatarLetter, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                if (c.isOnline) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AnshEmeraldPrimary))
                                }
                            }
                            Text("@${c.username} • ${c.lastSeenText}", fontSize = 10.sp, color = AnshTextMuted)
                        }

                        IconButton(onClick = { viewModel.initiateCall(c, CallType.VOICE) }) {
                            Icon(Icons.Outlined.Call, contentDescription = "Voice Call", tint = AnshEmeraldPrimary)
                        }
                        IconButton(onClick = { viewModel.initiateCall(c, CallType.VIDEO) }) {
                            Icon(Icons.Outlined.Videocam, contentDescription = "Video Call", tint = AnshCyanSecondary)
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("Add Peer Contact", color = AnshTextPrimary, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Full Name") })
                        OutlinedTextField(value = newUsername, onValueChange = { newUsername = it }, label = { Text("Username Handle") })
                        OutlinedTextField(value = newPhone, onValueChange = { newPhone = it }, label = { Text("Mobile Phone") })
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank() && newUsername.isNotBlank()) {
                                viewModel.addContact(newName, newUsername, newPhone, "$newUsername@ansh.internal")
                                showAddDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                    ) {
                        Text("Add to Vault", color = Color.Black)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) { Text("Cancel", color = AnshTextSecondary) }
                },
                containerColor = AnshObsidianBg
            )
        }

        AnshBottomBar(
            currentScreen = ScreenId.CONTACTS,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
fun ContactRequestsPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val requests by viewModel.contactRequests.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Peer Invites",
            subtitle = "${requests.size} Pending Handshakes",
            onBackClick = { viewModel.popBackStack() }
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(requests, key = { it.id }) { req ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(AnshCyanSecondary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(req.fullName.take(1), fontWeight = FontWeight.Bold, color = AnshCyanSecondary)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(req.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                            Text("${req.username} • Received ${req.timestamp}", fontSize = 10.sp, color = AnshTextMuted)
                        }

                        IconButton(onClick = { viewModel.acceptRequest(req.id) }) {
                            Icon(Icons.Outlined.Check, contentDescription = "Accept", tint = AnshEmeraldPrimary)
                        }
                        IconButton(onClick = { viewModel.rejectRequest(req.id) }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Reject", tint = AnshAlertRed)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val notifs by viewModel.notifications.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Security & Alerts",
            subtitle = "Audit Feeds",
            onBackClick = { viewModel.popBackStack() }
        )

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(notifs, key = { it.id }) { n ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = when (n.category) {
                                "Security" -> Icons.Outlined.Security
                                "Call" -> Icons.Outlined.Call
                                else -> Icons.Outlined.Notifications
                            },
                            contentDescription = null,
                            tint = if (n.category == "Security") AnshEmeraldPrimary else AnshCyanSecondary,
                            modifier = Modifier.size(22.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(n.title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text(n.timestamp, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextMuted)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(n.description, fontSize = 11.sp, color = AnshTextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacySecurityPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val user by viewModel.currentUser.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Privacy & Encryption",
            subtitle = "Cryptographic Controls",
            onBackClick = { viewModel.popBackStack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("END-TO-END CIPHER KEY", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshEmeraldPrimary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(user.publicKeyFingerprint, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = AnshCyanSecondary)
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingToggleRow(
                        title = "Two-Factor Authentication",
                        subtitle = "Hardware TOTP / SMS challenge required on unknown hosts",
                        checked = user.twoFactorEnabled,
                        onCheckedChange = { viewModel.toggle2FA() }
                    )
                    SettingToggleRow(
                        title = "Biometric Lock",
                        subtitle = "Require fingerprint or passcode upon app resumption",
                        checked = user.biometricLockEnabled,
                        onCheckedChange = { viewModel.toggleBiometric() }
                    )
                    SettingToggleRow(
                        title = "Read Receipts Transmit",
                        subtitle = "Deliver blue checkmarks when you read incoming packets",
                        checked = user.readReceiptsEnabled,
                        onCheckedChange = { viewModel.toggleReadReceipts() }
                    )
                    SettingToggleRow(
                        title = "Last Seen Visibility",
                        subtitle = "Broadcast online presence telemetry to contacts",
                        checked = user.lastSeenVisible,
                        onCheckedChange = { viewModel.toggleLastSeen() }
                    )
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    TextButton(onClick = { onNavigate(ScreenId.BLOCKED_USERS) }) {
                        Icon(Icons.Outlined.Block, contentDescription = null, tint = AnshAlertRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Manage Blocked Users Directory", color = AnshAlertRed, fontSize = 12.sp)
                    }
                    TextButton(onClick = { /* Export */ }) {
                        Icon(Icons.Outlined.Download, contentDescription = null, tint = AnshCyanSecondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export Cryptographic Audit Package", color = AnshCyanSecondary, fontSize = 12.sp)
                    }
                    TextButton(onClick = { onNavigate(ScreenId.WELCOME) }) {
                        Icon(Icons.Outlined.DeleteForever, contentDescription = null, tint = AnshAlertRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Wipe Local Enclave & Erase Identity", color = AnshAlertRed, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Terminal Settings",
            subtitle = "Environment Preferences",
            showBack = false
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SettingNavigationCard(
                icon = Icons.Outlined.Security,
                title = "Privacy & Encryption Suite",
                subtitle = "E2EE Keys, 2FA, Biometrics, and Read Receipts",
                onClick = { onNavigate(ScreenId.PRIVACY_SECURITY) }
            )

            SettingNavigationCard(
                icon = Icons.Outlined.Fingerprint,
                title = "Hardware Permissions Protocol",
                subtitle = "Inspect and grant real Camera, Mic, and Contact access",
                onClick = { viewModel.requestPermissions("ALL") }
            )

            SettingNavigationCard(
                icon = Icons.Outlined.Block,
                title = "Blocked Entities",
                subtitle = "Manage restricted peer identities",
                onClick = { onNavigate(ScreenId.BLOCKED_USERS) }
            )

            SettingNavigationCard(
                icon = Icons.Outlined.AdminPanelSettings,
                title = "Administrator Console",
                subtitle = "Audit logs, server telemetry, and user suspension",
                onClick = { onNavigate(ScreenId.ADMIN_DASHBOARD) }
            )

            SettingNavigationCard(
                icon = Icons.Outlined.HelpOutline,
                title = "Help, FAQ & Security Disclosure",
                subtitle = "Cryptographic whitepaper, documentation, and support",
                onClick = { onNavigate(ScreenId.HELP_SUPPORT) }
            )
        }

        AnshBottomBar(
            currentScreen = ScreenId.SETTINGS,
            onSelectScreen = onNavigate
        )
    }
}

@Composable
fun BlockedUsersPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val contacts by viewModel.contacts.collectAsState()
    val blocked = contacts.filter { it.isBlocked }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Blocked Users",
            subtitle = "${blocked.size} Restrained Identities",
            onBackClick = { viewModel.popBackStack() }
        )

        if (blocked.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No users are currently blocked", color = AnshTextMuted, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(blocked, key = { it.id }) { b ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Block, contentDescription = null, tint = AnshAlertRed)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(b.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                                Text("@${b.username}", fontSize = 10.sp, color = AnshTextMuted)
                            }
                            Button(
                                onClick = { viewModel.unblockUser(b.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                            ) {
                                Text("Unblock", color = Color.Black, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HelpSupportPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    var ticketText by remember { mutableStateOf("") }
    var ticketSubmitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Help & Security Whitepaper",
            subtitle = "Knowledge Center",
            onBackClick = { viewModel.popBackStack() }
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("CRYPTOGRAPHIC FAQ", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshEmeraldPrimary)
                    Spacer(modifier = Modifier.height(8.dp))
                    FaqItem(q = "How does E2EE function in ANSH CONNECT?", a = "Every device generates a local Curve25519 keypair. Symmetric session ciphers are negotiated via Diffie-Hellman handshakes with AES-256-GCM authentication.")
                    FaqItem(q = "Why is there a zero-emoji policy?", a = "ANSH CONNECT enforces clean vector SVG symbology to ensure non-distracting, high-clarity tactical communications without ambiguity.")
                    FaqItem(q = "Are voice and video streams recorded?", a = "Calls utilize direct WebRTC peer connections with SRTP encryption without middlebox persistence.")
                }
            }

            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("DISPATCH SECURITY TICKET", fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = AnshCyanSecondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = ticketText,
                        onValueChange = { ticketText = it },
                        label = { Text("Report issue or vulnerability") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AnshEmeraldPrimary,
                            unfocusedBorderColor = AnshGlassBorder,
                            focusedTextColor = AnshTextPrimary,
                            unfocusedTextColor = AnshTextPrimary
                        ),
                        maxLines = 4
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (ticketText.isNotBlank()) {
                                ticketSubmitted = true
                                ticketText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AnshEmeraldPrimary)
                    ) {
                        Text("SUBMIT TICKET", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    if (ticketSubmitted) {
                        Text("Ticket securely dispatched to ANSH SOC team.", color = AnshEmeraldLight, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingToggleRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
            Text(subtitle, fontSize = 10.sp, color = AnshTextMuted)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = AnshEmeraldPrimary)
        )
    }
}

@Composable
private fun SettingNavigationCard(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    GlassCard(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = AnshCyanSecondary, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                Text(subtitle, fontSize = 10.sp, color = AnshTextMuted)
            }
        }
    }
}

@Composable
private fun FaqItem(q: String, a: String) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text("Q: $q", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
        Text("A: $a", fontSize = 11.sp, color = AnshTextSecondary, lineHeight = 16.sp)
        Spacer(modifier = Modifier.height(4.dp))
    }
}
