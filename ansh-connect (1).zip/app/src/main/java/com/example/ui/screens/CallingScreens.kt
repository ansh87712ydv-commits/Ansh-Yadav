package com.example.ui.screens

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.CallMade
import androidx.compose.material.icons.automirrored.outlined.CallMissed
import androidx.compose.material.icons.automirrored.outlined.CallReceived
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.CallEnd
import androidx.compose.material.icons.outlined.Cameraswitch
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MicOff
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material.icons.outlined.VideocamOff
import androidx.compose.material.icons.outlined.VolumeOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CallState
import com.example.data.model.CallType
import com.example.data.model.ScreenId
import com.example.ui.components.AnshBottomBar
import com.example.ui.components.AnshTopBar
import com.example.ui.components.GlassCard
import com.example.ui.theme.AnshAlertRed
import com.example.ui.theme.AnshCyanSecondary
import com.example.ui.theme.AnshEmeraldLight
import com.example.ui.theme.AnshEmeraldPrimary
import com.example.ui.theme.AnshGlassBorder
import com.example.ui.theme.AnshObsidianBg
import com.example.ui.theme.AnshTextMuted
import com.example.ui.theme.AnshTextPrimary
import com.example.ui.theme.AnshTextSecondary
import com.example.ui.theme.AnshWarningAmber
import com.example.ui.viewmodel.AnshViewModel

@Composable
fun VoiceCallingPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val peer by viewModel.activeCallPeer.collectAsState()
    val callState by viewModel.activeCallState.collectAsState()
    val seconds by viewModel.callSeconds.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val isSpeakerOn by viewModel.isSpeakerOn.collectAsState()

    val minutes = seconds / 60
    val secs = seconds % 60
    val formattedDuration = String.format("%02d:%02d", minutes, secs)

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Security Protocol Header
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.terminateCall() }) {
                Icon(Icons.Outlined.CallEnd, contentDescription = "Minimize Call", tint = AnshTextMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "P2P ENCRYPTED WEBRTC",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = AnshEmeraldPrimary
                )
            }
            Box(modifier = Modifier.size(24.dp))
        }

        // Center Profile & Waveform
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(130.dp)
                    .scale(if (callState == CallState.CONNECTED) pulseScale else 1f)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(AnshEmeraldPrimary.copy(alpha = 0.3f), Color.Transparent)
                        )
                    )
                    .border(2.dp, AnshEmeraldPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(AnshGlassBorder),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = peer?.avatarLetter ?: "E",
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        color = AnshEmeraldPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = peer?.fullName ?: "Secure Peer",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AnshTextPrimary
            )

            Text(
                text = "@${peer?.username ?: "peer_node"}",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                color = AnshCyanSecondary
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (callState == CallState.RINGING) "Securing Opus Handshake..." else formattedDuration,
                fontSize = 18.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold,
                color = if (callState == CallState.RINGING) AnshWarningAmber else AnshEmeraldLight
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Simulated Audio Spectrum Waves
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(16, 28, 45, 30, 56, 38, 22, 48, 26, 14).forEach { h ->
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(if (callState == CallState.CONNECTED) (h * pulseScale).dp else 12.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(AnshEmeraldPrimary.copy(alpha = 0.8f))
                    )
                }
            }
        }

        // Bottom Call Controls
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CallControlButton(
                icon = if (isMuted) Icons.Outlined.MicOff else Icons.Outlined.Mic,
                label = if (isMuted) "Unmute" else "Mute",
                isActive = isMuted,
                onClick = { viewModel.toggleMute() }
            )

            CallControlButton(
                icon = if (isSpeakerOn) Icons.Outlined.VolumeUp else Icons.Outlined.VolumeOff,
                label = "Speaker",
                isActive = isSpeakerOn,
                onClick = { viewModel.toggleSpeaker() }
            )

            // Terminate Call Button
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(AnshAlertRed)
                    .clickable { viewModel.terminateCall() }
                    .testTag("end_call_btn"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.CallEnd,
                    contentDescription = "Terminate Call",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

@Composable
fun VideoCallingPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val peer by viewModel.activeCallPeer.collectAsState()
    val seconds by viewModel.callSeconds.collectAsState()
    val isMuted by viewModel.isMuted.collectAsState()
    val isCameraOff by viewModel.isCameraOff.collectAsState()

    val minutes = seconds / 60
    val secs = seconds % 60
    val formattedDuration = String.format("%02d:%02d", minutes, secs)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Remote Video Stream Representation
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF0F172A), Color(0xFF020617))
                    )
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .background(AnshCyanSecondary.copy(alpha = 0.2f))
                    .border(2.dp, AnshCyanSecondary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(peer?.avatarLetter ?: "E", fontSize = 42.sp, fontWeight = FontWeight.Black, color = AnshCyanSecondary)
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(peer?.fullName ?: "Encrypted Remote Feed", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
            Text("1080p60 • VP9 End-to-End Encrypted", fontSize = 11.sp, fontFamily = FontFamily.Monospace, color = AnshEmeraldLight)
            Text(formattedDuration, fontSize = 14.sp, fontFamily = FontFamily.Monospace, color = AnshTextSecondary, modifier = Modifier.padding(top = 4.dp))
        }

        // Picture-in-Picture Local Camera View
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 40.dp, end = 20.dp)
                .size(width = 100.dp, height = 140.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(AnshObsidianBg)
                .border(1.5.dp, AnshEmeraldPrimary, RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (isCameraOff) {
                Icon(Icons.Outlined.VideocamOff, contentDescription = "Camera disabled", tint = AnshAlertRed)
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.Security, contentDescription = null, tint = AnshEmeraldPrimary, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Self Feed", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextSecondary)
                }
            }
        }

        // Bottom Controls Overlay
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(20.dp),
            color = AnshObsidianBg.copy(alpha = 0.9f),
            shape = RoundedCornerShape(20.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, AnshGlassBorder)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.toggleMute() }) {
                    Icon(if (isMuted) Icons.Outlined.MicOff else Icons.Outlined.Mic, null, tint = if (isMuted) AnshAlertRed else AnshTextPrimary)
                }
                IconButton(onClick = { viewModel.toggleCamera() }) {
                    Icon(if (isCameraOff) Icons.Outlined.VideocamOff else Icons.Outlined.Videocam, null, tint = if (isCameraOff) AnshAlertRed else AnshTextPrimary)
                }
                IconButton(onClick = { /* camera switch */ }) {
                    Icon(Icons.Outlined.Cameraswitch, null, tint = AnshCyanSecondary)
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(AnshAlertRed)
                        .clickable { viewModel.terminateCall() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.CallEnd, contentDescription = "End Call", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun CallControlButton(
    icon: ImageVector,
    label: String,
    isActive: Boolean,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(if (isActive) AnshEmeraldPrimary.copy(alpha = 0.2f) else AnshGlassBorder)
                .border(1.dp, if (isActive) AnshEmeraldPrimary else AnshGlassBorder, CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) AnshEmeraldPrimary else AnshTextPrimary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, fontSize = 11.sp, color = AnshTextSecondary)
    }
}

@Composable
fun CallHistoryPage(
    viewModel: AnshViewModel,
    onNavigate: (ScreenId) -> Unit
) {
    val records by viewModel.callRecords.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    var filter by remember { mutableStateOf("ALL") }

    val filteredRecords = when (filter) {
        "MISSED" -> records.filter { it.isMissed }
        "VIDEO" -> records.filter { it.type == CallType.VIDEO }
        "VOICE" -> records.filter { it.type == CallType.VOICE }
        else -> records
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AnshObsidianBg)
    ) {
        AnshTopBar(
            title = "Call Logs",
            subtitle = "Encrypted Telephony",
            onBackClick = { viewModel.popBackStack() }
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("ALL", "MISSED", "VIDEO", "VOICE").forEach { f ->
                FilterChip(
                    selected = filter == f,
                    onClick = { filter = f },
                    label = { Text(f, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AnshEmeraldPrimary.copy(alpha = 0.2f),
                        selectedLabelColor = AnshEmeraldPrimary,
                        labelColor = AnshTextSecondary
                    )
                )
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredRecords, key = { it.id }) { call ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(if (call.isMissed) AnshAlertRed.copy(alpha = 0.15f) else AnshEmeraldPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when {
                                    call.isMissed -> Icons.AutoMirrored.Outlined.CallMissed
                                    call.isIncoming -> Icons.AutoMirrored.Outlined.CallReceived
                                    else -> Icons.AutoMirrored.Outlined.CallMade
                                },
                                contentDescription = null,
                                tint = if (call.isMissed) AnshAlertRed else AnshEmeraldPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(call.peerName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AnshTextPrimary)
                            Text("${call.peerHandle} • ${call.durationText}", fontSize = 10.sp, color = AnshTextMuted)
                            Text(call.timestamp, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = AnshTextSecondary)
                        }

                        IconButton(
                            onClick = {
                                val peer = contacts.find { it.fullName == call.peerName } ?: contacts.first()
                                viewModel.initiateCall(peer, call.type)
                            }
                        ) {
                            Icon(
                                imageVector = if (call.type == CallType.VIDEO) Icons.Outlined.Videocam else Icons.Outlined.Call,
                                contentDescription = "Call Back",
                                tint = AnshCyanSecondary
                            )
                        }
                    }
                }
            }
        }

        AnshBottomBar(
            currentScreen = ScreenId.CALL_HISTORY,
            onSelectScreen = onNavigate
        )
    }
}
