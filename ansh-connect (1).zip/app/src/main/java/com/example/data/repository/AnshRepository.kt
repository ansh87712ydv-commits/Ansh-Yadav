package com.example.data.repository

import com.example.data.model.AuditLog
import com.example.data.model.CallRecord
import com.example.data.model.CallState
import com.example.data.model.CallType
import com.example.data.model.ChatMessage
import com.example.data.model.ContactItem
import com.example.data.model.ContactRequestItem
import com.example.data.model.Conversation
import com.example.data.model.Gender
import com.example.data.model.LineReaction
import com.example.data.model.MessageStatus
import com.example.data.model.ModerationReport
import com.example.data.model.NetworkStatusState
import com.example.data.model.SecurityNotification
import com.example.data.model.SecurityTier
import com.example.data.model.StatusUpdate
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.model.VaultFile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class AnshRepository {

    private val _currentUser = MutableStateFlow(
        UserAccount(
            id = "usr_ansh_001",
            fullName = "Ansh Sharma",
            username = "ansh_sec",
            email = "ansh@anshconnect.internal",
            phone = "+91 98765 43210",
            dob = "1998-05-14",
            gender = Gender.MALE,
            bio = "Cybersecurity engineer & systems architect. Zero telemetry tolerance.",
            securityTier = SecurityTier.MAXIMUM_VAULT,
            isVerified = true,
            twoFactorEnabled = true,
            biometricLockEnabled = true,
            role = UserRole.ADMIN
        )
    )
    val currentUser: StateFlow<UserAccount> = _currentUser.asStateFlow()

    private val _networkStatus = MutableStateFlow(NetworkStatusState.CONNECTED)
    val networkStatus: StateFlow<NetworkStatusState> = _networkStatus.asStateFlow()

    private val _conversations = MutableStateFlow<List<Conversation>>(emptyList())
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    private val _messages = MutableStateFlow<Map<String, List<ChatMessage>>>(emptyMap())
    val messages: StateFlow<Map<String, List<ChatMessage>>> = _messages.asStateFlow()

    private val _contacts = MutableStateFlow<List<ContactItem>>(emptyList())
    val contacts: StateFlow<List<ContactItem>> = _contacts.asStateFlow()

    private val _contactRequests = MutableStateFlow<List<ContactRequestItem>>(emptyList())
    val contactRequests: StateFlow<List<ContactRequestItem>> = _contactRequests.asStateFlow()

    private val _callRecords = MutableStateFlow<List<CallRecord>>(emptyList())
    val callRecords: StateFlow<List<CallRecord>> = _callRecords.asStateFlow()

    private val _statusUpdates = MutableStateFlow<List<StatusUpdate>>(emptyList())
    val statusUpdates: StateFlow<List<StatusUpdate>> = _statusUpdates.asStateFlow()

    private val _vaultFiles = MutableStateFlow<List<VaultFile>>(emptyList())
    val vaultFiles: StateFlow<List<VaultFile>> = _vaultFiles.asStateFlow()

    private val _notifications = MutableStateFlow<List<SecurityNotification>>(emptyList())
    val notifications: StateFlow<List<SecurityNotification>> = _notifications.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLog>>(emptyList())
    val auditLogs: StateFlow<List<AuditLog>> = _auditLogs.asStateFlow()

    private val _moderationReports = MutableStateFlow<List<ModerationReport>>(emptyList())
    val moderationReports: StateFlow<List<ModerationReport>> = _moderationReports.asStateFlow()

    // Active Call State
    private val _activeCallState = MutableStateFlow(CallState.IDLE)
    val activeCallState: StateFlow<CallState> = _activeCallState.asStateFlow()

    private val _activeCallPeer = MutableStateFlow<ContactItem?>(null)
    val activeCallPeer: StateFlow<ContactItem?> = _activeCallPeer.asStateFlow()

    private val _activeCallType = MutableStateFlow(CallType.VOICE)
    val activeCallType: StateFlow<CallType> = _activeCallType.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isSpeakerOn = MutableStateFlow(false)
    val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

    private val _isCameraOff = MutableStateFlow(false)
    val isCameraOff: StateFlow<Boolean> = _isCameraOff.asStateFlow()

    init {
        seedInitialData()
    }

    private fun seedInitialData() {
        val initialContacts = listOf(
            ContactItem("c_1", "Elena Vance", "elena_v", "+1 415 555 0192", "elena@vance.lab", true, "Active now", avatarLetter = "E"),
            ContactItem("c_2", "Marcus Kane", "marcus_ops", "+44 20 7946 0912", "marcus@kaneops.uk", true, "Active 5m ago", avatarLetter = "M"),
            ContactItem("c_3", "Aarav Patel", "aarav_p", "+91 99887 76655", "aarav@pateltech.in", false, "Active 2h ago", avatarLetter = "A"),
            ContactItem("c_4", "Maya Lin", "maya_design", "+81 3 5555 0143", "maya@tokyodesign.jp", true, "Active now", avatarLetter = "M"),
            ContactItem("c_5", "David Zhang", "dzhang_crypto", "+1 206 555 0177", "david@elliptic.io", false, "Active yesterday", avatarLetter = "D"),
            ContactItem("c_6", "Sarah Connor", "sconnor", "+1 310 555 0184", "sarah@resistance.net", false, "Offline", isBlocked = true, avatarLetter = "S")
        )
        _contacts.value = initialContacts

        val initialConvs = listOf(
            Conversation(
                id = "conv_1",
                title = "Elena Vance",
                isGroup = false,
                subtitle = "Cryptographic handshakes confirmed.",
                lastMessage = "Public key verified with SHA256 checksum.",
                lastMessageTime = "10:42 PM",
                unreadCount = 2,
                avatarLetter = "E"
            ),
            Conversation(
                id = "conv_2",
                title = "Global Operations Vault",
                isGroup = true,
                subtitle = "Marcus Kane: Transmission completed.",
                lastMessage = "Encrypted bundle SHA-256 verified.",
                lastMessageTime = "09:15 PM",
                unreadCount = 0,
                isPinned = true,
                avatarLetter = "G",
                memberCount = 14
            ),
            Conversation(
                id = "conv_3",
                title = "Aarav Patel",
                isGroup = false,
                subtitle = "Shared a secure document.",
                lastMessage = "network_topology_v4.pdf [2.4 MB]",
                lastMessageTime = "Yesterday",
                unreadCount = 0,
                avatarLetter = "A"
            ),
            Conversation(
                id = "conv_4",
                title = "Maya Lin",
                isGroup = false,
                subtitle = "Call ended (14m 20s)",
                lastMessage = "UI vector schematics received.",
                lastMessageTime = "Yesterday",
                unreadCount = 0,
                avatarLetter = "M"
            )
        )
        _conversations.value = initialConvs

        val elenaMsgs = listOf(
            ChatMessage("m_1", "conv_1", "c_1", "Elena Vance", "Initiating peer-to-peer session over Diffie-Hellman channel.", "10:30 PM", MessageStatus.READ),
            ChatMessage("m_2", "conv_1", "usr_ansh_001", "Ansh Sharma", "Handshake confirmed. Cipher AES-256-GCM established.", "10:32 PM", MessageStatus.READ),
            ChatMessage("m_3", "conv_1", "c_1", "Elena Vance", "Attached the audit matrix for firewall node #4.", "10:35 PM", MessageStatus.READ, attachmentName = "security_audit_node4.pdf", attachmentType = "PDF", attachmentSize = "1.8 MB", reactions = listOf(LineReaction.SHIELD, LineReaction.CHECK)),
            ChatMessage("m_4", "conv_1", "c_1", "Elena Vance", "Public key verified with SHA256 checksum.", "10:42 PM", MessageStatus.DELIVERED, reactions = listOf(LineReaction.STAR))
        )
        val groupMsgs = listOf(
            ChatMessage("gm_1", "conv_2", "c_2", "Marcus Kane", "All regional gateways are synchronized with TLS 1.3.", "09:00 PM", MessageStatus.READ),
            ChatMessage("gm_2", "conv_2", "c_4", "Maya Lin", "New glassmorphism HUD interface tokens deployed.", "09:10 PM", MessageStatus.READ, reactions = listOf(LineReaction.HEART, LineReaction.THUMBS_UP)),
            ChatMessage("gm_3", "conv_2", "usr_ansh_001", "Ansh Sharma", "Encrypted bundle SHA-256 verified.", "09:15 PM", MessageStatus.SENT)
        )
        _messages.value = mapOf("conv_1" to elenaMsgs, "conv_2" to groupMsgs)

        _callRecords.value = listOf(
            CallRecord("cal_1", "Elena Vance", "@elena_v", CallType.VIDEO, "Today, 08:30 PM", "12m 45s", isIncoming = true, isMissed = false),
            CallRecord("cal_2", "Marcus Kane", "@marcus_ops", CallType.VOICE, "Today, 04:12 PM", "0m 00s", isIncoming = true, isMissed = true),
            CallRecord("cal_3", "Maya Lin", "@maya_design", CallType.VOICE, "Yesterday, 06:15 PM", "14m 20s", isIncoming = false, isMissed = false),
            CallRecord("cal_4", "David Zhang", "@dzhang_crypto", CallType.VIDEO, "Nov 9, 11:20 AM", "4m 10s", isIncoming = false, isMissed = false)
        )

        _statusUpdates.value = listOf(
            StatusUpdate("st_1", "usr_ansh_001", "My Status", "Security hardening complete for server cluster #7.", "15m ago", viewersCount = 18, isMine = true, hasUnseen = false),
            StatusUpdate("st_2", "c_1", "Elena Vance", "Deploying quantum-resistant signature pilot.", "1h ago", viewersCount = 42, hasUnseen = true),
            StatusUpdate("st_3", "c_4", "Maya Lin", "Vector UI designs updated without any emoji glyphs.", "3h ago", viewersCount = 35, hasUnseen = true),
            StatusUpdate("st_4", "c_2", "Marcus Kane", "London datacenter zero-loss maintenance finished.", "5h ago", viewersCount = 29, hasUnseen = false)
        )

        _vaultFiles.value = listOf(
            VaultFile("vf_1", "ansh_security_manifest.pdf", "PDF", "3.4 MB", "Nov 11, 2026", "PDF"),
            VaultFile("vf_2", "gateway_certificates_bundle.zip", "ZIP", "14.2 MB", "Nov 10, 2026", "ZIP"),
            VaultFile("vf_3", "firewall_ruleset_matrix.xlsx", "XLSX", "840 KB", "Nov 9, 2026", "XLS"),
            VaultFile("vf_4", "infrastructure_blueprint.docx", "DOCX", "1.1 MB", "Nov 8, 2026", "DOC"),
            VaultFile("vf_5", "datacenter_layout_cam.mp4", "MP4", "45.0 MB", "Nov 7, 2026", "MP4"),
            VaultFile("vf_6", "threat_model_presentation.pptx", "PPTX", "9.6 MB", "Nov 5, 2026", "PPT")
        )

        _notifications.value = listOf(
            SecurityNotification("notif_1", "New Device Registered", "Android Client logged in via SHA256 challenge.", "Security", "10m ago"),
            SecurityNotification("notif_2", "Encrypted Channel Opened", "Elena Vance shared end-to-end cipher credentials.", "Message", "1h ago"),
            SecurityNotification("notif_3", "Missed Encrypted Voice Call", "Marcus Kane requested secure audio stream.", "Call", "4h ago"),
            SecurityNotification("notif_4", "Firewall Integrity Check Passed", "System audit finished with 0 anomalies.", "System", "8h ago")
        )

        _auditLogs.value = listOf(
            AuditLog("aud_1", "User Login (MFA Verified)", "192.168.1.104", "Pixel 9 Pro", "Nov 11 2026, 21:00"),
            AuditLog("aud_2", "E2EE Key Rotation Executed", "192.168.1.104", "Pixel 9 Pro", "Nov 11 2026, 20:30"),
            AuditLog("aud_3", "Vault File Downloaded (ID: vf_1)", "192.168.1.104", "Pixel 9 Pro", "Nov 11 2026, 18:22"),
            AuditLog("aud_4", "Blocked Connection Attempt", "203.0.113.44", "Unknown Linux Host", "Nov 11 2026, 15:10", isHighRisk = true)
        )

        _moderationReports.value = listOf(
            ModerationReport("rep_1", "@shadow_recon", "@aarav_p", "Suspected port scan inquiry in DM", "Today 14:20", "PENDING_REVIEW"),
            ModerationReport("rep_2", "@spammer_bot99", "@marcus_ops", "Repeated automated unsolicited invitations", "Yesterday", "ACTION_TAKEN")
        )

        _contactRequests.value = listOf(
            ContactRequestItem("cr_1", "Liam Neeson", "@liam_def", "10m ago", isIncoming = true),
            ContactRequestItem("cr_2", "Rhea Ripley", "@rhea_m", "2h ago", isIncoming = true)
        )
    }

    fun sendMessage(conversationId: String, text: String, attachmentName: String? = null, attachmentType: String? = null, attachmentSize: String? = null) {
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val newMsg = ChatMessage(
            id = "m_${UUID.randomUUID().toString().take(8)}",
            conversationId = conversationId,
            senderId = _currentUser.value.id,
            senderName = _currentUser.value.fullName,
            content = text,
            timestamp = timeNow,
            status = MessageStatus.SENT,
            isEncrypted = true,
            attachmentName = attachmentName,
            attachmentType = attachmentType,
            attachmentSize = attachmentSize
        )
        _messages.update { currentMap ->
            val list = currentMap[conversationId].orEmpty() + newMsg
            currentMap + (conversationId to list)
        }
        _conversations.update { convs ->
            convs.map { c ->
                if (c.id == conversationId) {
                    c.copy(lastMessage = text.ifBlank { attachmentName ?: "Encrypted media" }, lastMessageTime = timeNow)
                } else c
            }
        }
    }

    fun toggleReaction(conversationId: String, messageId: String, reaction: LineReaction) {
        _messages.update { currentMap ->
            val list = currentMap[conversationId]?.map { msg ->
                if (msg.id == messageId) {
                    val updatedReactions = if (msg.reactions.contains(reaction)) {
                        msg.reactions - reaction
                    } else {
                        msg.reactions + reaction
                    }
                    msg.copy(reactions = updatedReactions)
                } else msg
            }.orEmpty()
            currentMap + (conversationId to list)
        }
    }

    fun togglePinMessage(conversationId: String, messageId: String) {
        _messages.update { currentMap ->
            val list = currentMap[conversationId]?.map { msg ->
                if (msg.id == messageId) msg.copy(isPinned = !msg.isPinned) else msg
            }.orEmpty()
            currentMap + (conversationId to list)
        }
    }

    fun toggleStarMessage(conversationId: String, messageId: String) {
        _messages.update { currentMap ->
            val list = currentMap[conversationId]?.map { msg ->
                if (msg.id == messageId) msg.copy(isStarred = !msg.isStarred) else msg
            }.orEmpty()
            currentMap + (conversationId to list)
        }
    }

    fun deleteMessage(conversationId: String, messageId: String) {
        _messages.update { currentMap ->
            val list = currentMap[conversationId]?.filterNot { it.id == messageId }.orEmpty()
            currentMap + (conversationId to list)
        }
    }

    fun startCall(peer: ContactItem, type: CallType) {
        _activeCallPeer.value = peer
        _activeCallType.value = type
        _activeCallState.value = CallState.RINGING
        _isMuted.value = false
        _isCameraOff.value = false
        _isSpeakerOn.value = false
    }

    fun connectCall() {
        _activeCallState.value = CallState.CONNECTED
    }

    fun endCall() {
        val peer = _activeCallPeer.value
        val type = _activeCallType.value
        if (peer != null) {
            val record = CallRecord(
                id = "cal_${UUID.randomUUID().toString().take(6)}",
                peerName = peer.fullName,
                peerHandle = "@${peer.username}",
                type = type,
                timestamp = "Just now",
                durationText = "0m 45s",
                isIncoming = false,
                isMissed = false
            )
            _callRecords.update { listOf(record) + it }
        }
        _activeCallState.value = CallState.ENDED
        _activeCallPeer.value = null
    }

    fun toggleMute() {
        _isMuted.update { !it }
    }

    fun toggleSpeaker() {
        _isSpeakerOn.update { !it }
    }

    fun toggleCamera() {
        _isCameraOff.update { !it }
    }

    fun addContact(name: String, username: String, phone: String, email: String) {
        val newC = ContactItem(
            id = "c_${UUID.randomUUID().toString().take(6)}",
            fullName = name,
            username = username.removePrefix("@"),
            phone = phone,
            email = email,
            isOnline = true,
            lastSeenText = "Added just now",
            avatarLetter = name.take(1).uppercase()
        )
        _contacts.update { listOf(newC) + it }
    }

    fun blockUser(contactId: String) {
        _contacts.update { list ->
            list.map { if (it.id == contactId) it.copy(isBlocked = true) else it }
        }
    }

    fun unblockUser(contactId: String) {
        _contacts.update { list ->
            list.map { if (it.id == contactId) it.copy(isBlocked = false) else it }
        }
    }

    fun acceptContactRequest(requestId: String) {
        val req = _contactRequests.value.find { it.id == requestId }
        if (req != null) {
            addContact(req.fullName, req.username, "+1 555 0199", "${req.username}@ansh.internal")
            _contactRequests.update { it.filterNot { r -> r.id == requestId } }
        }
    }

    fun rejectContactRequest(requestId: String) {
        _contactRequests.update { it.filterNot { it.id == requestId } }
    }

    fun uploadVaultFile(fileName: String, category: String, sizeText: String) {
        val ext = fileName.substringAfterLast('.', "DAT").uppercase()
        val file = VaultFile(
            id = "vf_${UUID.randomUUID().toString().take(6)}",
            fileName = fileName,
            extension = ext,
            sizeText = sizeText,
            uploadedAt = "Just now",
            category = category,
            isEncrypted = true,
            downloadProgress = 1.0f
        )
        _vaultFiles.update { listOf(file) + it }
    }

    fun postStatus(caption: String) {
        val newS = StatusUpdate(
            id = "st_${UUID.randomUUID().toString().take(6)}",
            userId = _currentUser.value.id,
            userName = "My Status",
            textSnippet = caption,
            timestamp = "Just now",
            viewersCount = 0,
            isMine = true,
            hasUnseen = false
        )
        _statusUpdates.update { listOf(newS) + it }
    }

    fun updateProfile(fullName: String, bio: String, phone: String, email: String, gender: Gender) {
        _currentUser.update {
            it.copy(fullName = fullName, bio = bio, phone = phone, email = email, gender = gender)
        }
    }

    fun toggleTwoFactor() {
        _currentUser.update { it.copy(twoFactorEnabled = !it.twoFactorEnabled) }
    }

    fun toggleBiometric() {
        _currentUser.update { it.copy(biometricLockEnabled = !it.biometricLockEnabled) }
    }

    fun toggleReadReceipts() {
        _currentUser.update { it.copy(readReceiptsEnabled = !it.readReceiptsEnabled) }
    }

    fun toggleLastSeen() {
        _currentUser.update { it.copy(lastSeenVisible = !it.lastSeenVisible) }
    }

    fun setNetworkStatus(status: NetworkStatusState) {
        _networkStatus.value = status
    }

    fun dismissReport(reportId: String) {
        _moderationReports.update { it.filterNot { r -> r.id == reportId } }
    }
}
