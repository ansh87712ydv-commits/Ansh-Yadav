package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * All 34 distinct navigation screens for ANSH CONNECT
 */
enum class ScreenId {
    HOME,
    WELCOME,
    LOGIN,
    REGISTRATION,
    MOBILE_OTP,
    EMAIL_OTP,
    HUMAN_VERIFICATION,
    MAIN_DASHBOARD,
    USER_PROFILE,
    EDIT_PROFILE,
    CHATTING,
    PRIVATE_CHAT,
    GROUP_CHAT,
    STATUS,
    VOICE_CALLING,
    VIDEO_CALLING,
    CALL_HISTORY,
    CONTACTS,
    CONTACT_REQUESTS,
    FILE_SHARING,
    NOTIFICATION,
    PRIVACY_SECURITY,
    SETTINGS,
    BLOCKED_USERS,
    HELP_SUPPORT,
    ADMIN_LOGIN,
    ADMIN_DASHBOARD,
    USER_MANAGEMENT,
    REPORTS_MODERATION,
    ERROR_404,
    ERROR_500,
    ERROR_502,
    NETWORK_ERROR,
    MAINTENANCE
}

enum class Gender {
    MALE,
    FEMALE,
    OTHER,
    PREFER_NOT_TO_SAY
}

enum class SecurityTier {
    STANDARD,
    ENHANCED_SHIELD,
    MAXIMUM_VAULT
}

enum class MessageStatus {
    SENT,
    DELIVERED,
    READ
}

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallState {
    IDLE,
    DIALING,
    RINGING,
    CONNECTED,
    ENDED
}

enum class NetworkStatusState {
    CONNECTED,
    SLOW,
    RECONNECTING,
    DISCONNECTED
}

enum class UserRole {
    USER,
    MODERATOR,
    ADMIN
}

/**
 * Strict Line Reactions - Zero Emoji Rule
 */
enum class LineReaction(val label: String, val icon: ImageVector) {
    THUMBS_UP("Acknowledge", Icons.Outlined.ThumbUp),
    HEART("Appreciate", Icons.Outlined.FavoriteBorder),
    STAR("Important", Icons.Outlined.Star),
    SHIELD("Verified", Icons.Outlined.Security),
    CHECK("Done", Icons.Outlined.Check),
    FLAG("Notice", Icons.Outlined.Flag)
}

data class UserAccount(
    val id: String,
    val fullName: String,
    val username: String,
    val email: String,
    val phone: String,
    val dob: String,
    val gender: Gender,
    val bio: String,
    val securityTier: SecurityTier = SecurityTier.MAXIMUM_VAULT,
    val isVerified: Boolean = true,
    val twoFactorEnabled: Boolean = true,
    val biometricLockEnabled: Boolean = false,
    val readReceiptsEnabled: Boolean = true,
    val lastSeenVisible: Boolean = true,
    val publicKeyFingerprint: String = "SHA256:7f8a9e1b2c3d4e5f60718293a4b5c6d7e8f90123",
    val role: UserRole = UserRole.USER
)

data class ChatMessage(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val content: String,
    val timestamp: String,
    val status: MessageStatus = MessageStatus.READ,
    val isEncrypted: Boolean = true,
    val isPinned: Boolean = false,
    val isStarred: Boolean = false,
    val attachmentName: String? = null,
    val attachmentType: String? = null,
    val attachmentSize: String? = null,
    val reactions: List<LineReaction> = emptyList(),
    val replyToSnippet: String? = null
)

data class Conversation(
    val id: String,
    val title: String,
    val isGroup: Boolean,
    val subtitle: String,
    val lastMessage: String,
    val lastMessageTime: String,
    val unreadCount: Int = 0,
    val isMuted: Boolean = false,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val avatarLetter: String,
    val memberCount: Int = 2
)

data class CallRecord(
    val id: String,
    val peerName: String,
    val peerHandle: String,
    val type: CallType,
    val timestamp: String,
    val durationText: String,
    val isIncoming: Boolean,
    val isMissed: Boolean
)

data class ContactItem(
    val id: String,
    val fullName: String,
    val username: String,
    val phone: String,
    val email: String,
    val isOnline: Boolean,
    val lastSeenText: String,
    val isBlocked: Boolean = false,
    val isFavorite: Boolean = false,
    val avatarLetter: String
)

data class ContactRequestItem(
    val id: String,
    val fullName: String,
    val username: String,
    val timestamp: String,
    val isIncoming: Boolean
)

data class StatusUpdate(
    val id: String,
    val userId: String,
    val userName: String,
    val textSnippet: String,
    val timestamp: String,
    val viewersCount: Int = 0,
    val isMine: Boolean = false,
    val hasUnseen: Boolean = true
)

data class VaultFile(
    val id: String,
    val fileName: String,
    val extension: String,
    val sizeText: String,
    val uploadedAt: String,
    val category: String, // PDF, DOC, XLS, PPT, JPG, MP4, ZIP
    val isEncrypted: Boolean = true,
    val downloadProgress: Float = 1.0f
)

data class SecurityNotification(
    val id: String,
    val title: String,
    val description: String,
    val category: String, // Security, Call, Message, System
    val timestamp: String,
    val isRead: Boolean = false
)

data class AuditLog(
    val id: String,
    val event: String,
    val ipAddress: String,
    val device: String,
    val timestamp: String,
    val isHighRisk: Boolean = false
)

data class ModerationReport(
    val id: String,
    val targetUser: String,
    val reportedBy: String,
    val reason: String,
    val timestamp: String,
    val status: String
)
